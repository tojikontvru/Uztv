/**
 * SalomTV — Main Server
 * Node.js + Express + SQLite with OAuth Support
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const path = require('path');

// Import routes
const authRoutes = require('./routes/auth');
const channelsRoutes = require('./routes/channels');
const categoriesRoutes = require('./routes/categories');
const usersRoutes = require('./routes/users');
const publicRoutes = require('./routes/public');
const oauthRoutes = require('./routes/oauth');

// Initialize database
const { setup } = require('./database');
setup();

// Initialize app
const app = express();
const PORT = process.env.PORT || 3000;

// Environment variables
const {
  GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET,
  YANDEX_CLIENT_ID,
  YANDEX_CLIENT_SECRET,
  SESSION_SECRET
} = process.env;

// Middleware
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false
}));
app.use(cors({
  origin: true,
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Static files
app.use(express.static(path.join(__dirname, '../public')));

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/oauth', oauthRoutes);
app.use('/api/channels', channelsRoutes);
app.use('/api/categories', categoriesRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/public', publicRoutes);

// Main page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Login page
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/login.html'));
});

// Registration page
app.get('/register', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/register.html'));
});

// Profile/Dashboard page
app.get('/profile', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/profile.html'));
});

// Admin panel
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/admin.html'));
});

// OAuth callbacks
app.get('/auth/google', (req, res) => {
  res.redirect('/login?oauth=google');
});

app.get('/auth/yandex', (req, res) => {
  res.redirect('/login?oauth=yandex');
});

// 404 handler
app.use((req, res, next) => {
  if (req.accepts('html')) {
    res.status(404).sendFile(path.join(__dirname, '../public/404.html'));
  } else {
    res.status(404).json({ error: 'Not found' });
  }
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('Server Error:', err);
  res.status(err.status || 500).json({
    success: false,
    error: process.env.NODE_ENV === 'production'
      ? 'Internal server error'
      : err.message
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════════════╗
║                                                      ║
║   📺 SalomTV Platform запущен                       ║
║                                                      ║
║   🌐 URL: http://localhost:${PORT}                     ║
║   👤 Profile: http://localhost:${PORT}/profile        ║
║   📝 API:  http://localhost:${PORT}/api               ║
║                                                      ║
║   OAuth Configuration:                              ║
║   - Google: ${GOOGLE_CLIENT_ID ? '✓ Configured' : '✗ Not set'}                         ║
║   - Yandex: ${YANDEX_CLIENT_ID ? '✓ Configured' : '✗ Not set'}                         ║
║                                                      ║
║   Default Admin:                                     ║
║   Email: admin@salomtv.uz                           ║
║   Password: admin123                                ║
║                                                      ║
╚══════════════════════════════════════════════════════╝
  `);
});

module.exports = app;