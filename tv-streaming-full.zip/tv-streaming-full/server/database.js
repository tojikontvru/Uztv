/**
 * SalomTV — Database Setup
 * SQLite Database Configuration with OAuth Support
 */

const Database = require('better-sqlite3');
const path = require('path');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const DB_PATH = path.join(__dirname, '..', 'database.sqlite');
const db = new Database(DB_PATH);

// Enable foreign keys
db.pragma('foreign_keys = ON');

// Initialize tables
function initDatabase() {
  console.log('📦 Initializing database...');

  // Users table with OAuth support
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT,
      role TEXT DEFAULT 'user' CHECK(role IN ('user', 'admin')),
      oauth_provider TEXT,
      oauth_id TEXT,
      avatar TEXT,
      preferred_language TEXT DEFAULT 'ru',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(oauth_provider, oauth_id)
    )
  `);

  // Devices table for multi-device support
  db.exec(`
    CREATE TABLE IF NOT EXISTS devices (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      device_name TEXT NOT NULL,
      device_type TEXT DEFAULT 'web',
      device_id TEXT NOT NULL,
      last_active DATETIME DEFAULT CURRENT_TIMESTAMP,
      ip_address TEXT,
      user_agent TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )
  `);

  // Categories table with TJ language support
  db.exec(`
    CREATE TABLE IF NOT EXISTS categories (
      id TEXT PRIMARY KEY,
      name_ru TEXT NOT NULL,
      name_en TEXT NOT NULL,
      name_uz TEXT NOT NULL,
      name_tj TEXT NOT NULL,
      icon TEXT DEFAULT 'tv',
      sort_order INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Channels table
  db.exec(`
    CREATE TABLE IF NOT EXISTS channels (
      id TEXT PRIMARY KEY,
      flusonic_id TEXT,
      title_ru TEXT NOT NULL,
      title_en TEXT,
      title_uz TEXT,
      title_tj TEXT,
      description_ru TEXT,
      description_en TEXT,
      description_uz TEXT,
      description_tj TEXT,
      image TEXT,
      url TEXT,
      background_image TEXT,
      payment_type TEXT DEFAULT 'free' CHECK(payment_type IN ('free', 'svod')),
      resolution TEXT DEFAULT 'HD' CHECK(resolution IN ('HD', 'FULL HD')),
      status INTEGER DEFAULT 1,
      has_access INTEGER DEFAULT 1,
      category_ids TEXT DEFAULT '[]',
      current_program TEXT,
      program_schedule TEXT DEFAULT '[]',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Sessions table
  db.exec(`
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      token TEXT NOT NULL,
      expires_at DATETIME NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )
  `);

  // Activity logs
  db.exec(`
    CREATE TABLE IF NOT EXISTS activity_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT,
      action TEXT NOT NULL,
      entity_type TEXT,
      entity_id TEXT,
      details TEXT,
      ip_address TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    )
  `);

  // User favorites
  db.exec(`
    CREATE TABLE IF NOT EXISTS favorites (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(user_id, channel_id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (channel_id) REFERENCES channels(id) ON DELETE CASCADE
    )
  `);

  // Watch history
  db.exec(`
    CREATE TABLE IF NOT EXISTS watch_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      duration INTEGER DEFAULT 0,
      watched_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (channel_id) REFERENCES channels(id) ON DELETE CASCADE
    )
  `);

  console.log('✅ Tables created');
}

// Create default admin
function createDefaultAdmin() {
  const existingAdmin = db.prepare('SELECT id FROM users WHERE role = ?').get('admin');

  if (!existingAdmin) {
    const hashedPassword = bcrypt.hashSync('admin123', 10);
    const adminId = uuidv4();

    db.prepare(`
      INSERT INTO users (id, username, email, password, role)
      VALUES (?, ?, ?, ?, ?)
    `).run(adminId, 'admin', 'admin@salomtv.uz', hashedPassword, 'admin');

    console.log('👤 Default admin created:');
    console.log('   Email: admin@salomtv.uz');
    console.log('   Password: admin123');
    console.log('   ⚠️  Change password after first login!');
  }
}

// Initialize default categories
function createDefaultCategories() {
  const count = db.prepare('SELECT COUNT(*) as count FROM categories').get().count;

  if (count === 0) {
    const defaultCategories = [
      { id: uuidv4(), name_ru: 'Основной пакет', name_en: 'Main Package', name_uz: 'Asosiy paket', name_tj: 'Бастапқи пакет', icon: 'tv', order: 1 },
      { id: uuidv4(), name_ru: 'Местные каналы', name_en: 'Local Channels', name_uz: 'Mahalliy kanallar', name_tj: 'Маҳаллӣ каналҳо', icon: 'map-pin', order: 2 },
      { id: uuidv4(), name_ru: 'Кино', name_en: 'Movies', name_uz: 'Kino', name_tj: 'Филмҳо', icon: 'film', order: 3 },
      { id: uuidv4(), name_ru: 'Новости', name_en: 'News', name_uz: 'Yangiliklar', name_tj: 'Ахбор', icon: 'rss', order: 4 },
      { id: uuidv4(), name_ru: 'Познавательные', name_en: 'Educational', name_uz: "O'qitish", name_tj: 'Омӯзишӣ', icon: 'book', order: 5 },
      { id: uuidv4(), name_ru: 'Спорт', name_en: 'Sport', name_uz: 'Sport', name_tj: 'Варзиш', icon: 'globe', order: 6 },
      { id: uuidv4(), name_ru: 'Детские', name_en: 'Kids', name_uz: 'Bolalar', name_tj: 'Кӯдакон', icon: 'star', order: 7 },
      { id: uuidv4(), name_ru: 'Музыка', name_en: 'Music', name_uz: 'Musiqa', name_tj: 'Мӯзика', icon: 'music', order: 8 },
      { id: uuidv4(), name_ru: 'Международные', name_en: 'International', name_uz: 'Xalqaro', name_tj: 'Байналмилалӣ', icon: 'globe', order: 9 }
    ];

    const insertCategory = db.prepare(`
      INSERT INTO categories (id, name_ru, name_en, name_uz, name_tj, icon, sort_order)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    defaultCategories.forEach(cat => {
      insertCategory.run(cat.id, cat.name_ru, cat.name_en, cat.name_uz, cat.name_tj, cat.icon, cat.order);
    });

    console.log('📂 Categories created');
  }
}

// Get user's active devices count
function getUserDeviceCount(userId) {
  const result = db.prepare('SELECT COUNT(*) as count FROM devices WHERE user_id = ?').get(userId);
  return result.count;
}

// Check if user can add more devices
function canAddDevice(userId, maxDevices = 3) {
  const count = getUserDeviceCount(userId);
  return count < maxDevices;
}

// Setup
function setup() {
  initDatabase();
  createDefaultAdmin();
  createDefaultCategories();
  console.log('✅ Database ready\n');
}

// Export
module.exports = {
  db,
  setup,
  initDatabase,
  createDefaultAdmin,
  createDefaultCategories,
  getUserDeviceCount,
  canAddDevice
};