/**
 * SalomTV — Authentication Middleware
 * JWT Verification & Authorization
 */

const jwt = require('jsonwebtoken');
const { db } = require('../database');

const JWT_SECRET = process.env.JWT_SECRET || 'salomtv-secret-key-change-in-production';
const JWT_EXPIRES = '7d';

// Generate token
function generateToken(user) {
  return jwt.sign(
    {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      preferred_language: user.preferred_language || 'ru'
    },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES }
  );
}

// Verify token
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    return null;
  }
}

// Middleware: Authentication
function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      error: 'Authorization required'
    });
  }

  const token = authHeader.split(' ')[1];
  const decoded = verifyToken(token);

  if (!decoded) {
    return res.status(401).json({
      success: false,
      error: 'Invalid or expired token'
    });
  }

  // Get user from DB
  const user = db.prepare('SELECT id, username, email, role, preferred_language FROM users WHERE id = ?').get(decoded.id);

  if (!user) {
    return res.status(401).json({
      success: false,
      error: 'User not found'
    });
  }

  req.user = user;
  next();
}

// Middleware: Admin check
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      error: 'Admin access required'
    });
  }
  next();
}

// Middleware: Guest only
function guestOnly(req, res, next) {
  const authHeader = req.headers.authorization;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    const decoded = verifyToken(token);

    if (decoded) {
      return res.status(400).json({
        success: false,
        error: 'Already logged in'
      });
    }
  }

  next();
}

// Activity logging
function logActivity(userId, action, entityType, entityId, details, ipAddress) {
  try {
    db.prepare(`
      INSERT INTO activity_logs (user_id, action, entity_type, entity_id, details, ip_address)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(userId, action, entityType, entityId, details, ipAddress);
  } catch (error) {
    console.error('Activity log error:', error);
  }
}

module.exports = {
  JWT_SECRET,
  JWT_EXPIRES,
  generateToken,
  verifyToken,
  authenticate,
  requireAdmin,
  guestOnly,
  logActivity
};