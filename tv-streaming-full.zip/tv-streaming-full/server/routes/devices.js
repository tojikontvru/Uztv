/**
 * SalomTV — Devices Routes
 * Device management for multi-device support
 */

const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { db, getUserDeviceCount, canAddDevice } = require('../database');
const { authenticate, logActivity } = require('../middleware/auth');

const router = express.Router();
const MAX_DEVICES = 3;

// ============================================
// GET /api/users/devices — Get user devices
// ============================================
router.get('/devices', authenticate, (req, res) => {
  try {
    const userId = req.user.id;

    const devices = db.prepare(`
      SELECT id, device_name, device_type, device_id, last_active, ip_address, user_agent, created_at
      FROM devices
      WHERE user_id = ?
      ORDER BY last_active DESC
    `).all(userId);

    const deviceCount = getUserDeviceCount(userId);

    res.json({
      success: true,
      devices,
      deviceLimit: {
        current: deviceCount,
        max: MAX_DEVICES,
        canAdd: deviceCount < MAX_DEVICES
      }
    });

  } catch (error) {
    console.error('Get devices error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get devices'
    });
  }
});

// ============================================
// POST /api/users/devices — Register new device
// ============================================
router.post('/devices', authenticate, (req, res) => {
  try {
    const userId = req.user.id;
    const { device_name, device_type, device_id, ip_address, user_agent } = req.body;

    if (!device_id) {
      return res.status(400).json({
        success: false,
        error: 'Device ID is required'
      });
    }

    // Check device limit
    const currentCount = getUserDeviceCount(userId);
    if (currentCount >= MAX_DEVICES) {
      return res.status(403).json({
        success: false,
        error: `Maximum device limit reached (${MAX_DEVICES}). Please remove a device to add a new one.`,
        deviceLimit: {
          current: currentCount,
          max: MAX_DEVICES
        }
      });
    }

    // Check if device already exists
    const existingDevice = db.prepare('SELECT id FROM devices WHERE user_id = ? AND device_id = ?')
      .get(userId, device_id);

    if (existingDevice) {
      // Update last active
      db.prepare('UPDATE devices SET last_active = CURRENT_TIMESTAMP, ip_address = ?, user_agent = ? WHERE id = ?')
        .run(ip_address, user_agent, existingDevice.id);
    } else {
      // Create new device
      const deviceDbId = uuidv4();
      db.prepare(`
        INSERT INTO devices (id, user_id, device_name, device_type, device_id, ip_address, user_agent)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).run(deviceDbId, userId, device_name || 'Unknown Device', device_type || 'web', device_id, ip_address, user_agent);

      logActivity(userId, 'device_added', 'device', deviceDbId, `Device registered: ${device_name}`, ip_address);
    }

    const devices = db.prepare('SELECT * FROM devices WHERE user_id = ? ORDER BY last_active DESC').all(userId);
    const deviceCount = getUserDeviceCount(userId);

    res.json({
      success: true,
      message: 'Device registered successfully',
      devices,
      deviceLimit: {
        current: deviceCount,
        max: MAX_DEVICES,
        canAdd: deviceCount < MAX_DEVICES
      }
    });

  } catch (error) {
    console.error('Register device error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to register device'
    });
  }
});

// ============================================
// PUT /api/users/devices/:id — Update device
// ============================================
router.put('/devices/:id', authenticate, (req, res) => {
  try {
    const userId = req.user.id;
    const deviceId = req.params.id;
    const { device_name, ip_address, user_agent } = req.body;

    // Verify device belongs to user
    const device = db.prepare('SELECT * FROM devices WHERE id = ? AND user_id = ?')
      .get(deviceId, userId);

    if (!device) {
      return res.status(404).json({
        success: false,
        error: 'Device not found'
      });
    }

    // Update device
    db.prepare(`
      UPDATE devices
      SET device_name = COALESCE(?, device_name),
          ip_address = COALESCE(?, ip_address),
          user_agent = COALESCE(?, user_agent),
          last_active = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(device_name, ip_address, user_agent, deviceId);

    logActivity(userId, 'device_updated', 'device', deviceId, `Device updated: ${device_name}`, ip_address);

    const devices = db.prepare('SELECT * FROM devices WHERE user_id = ? ORDER BY last_active DESC').all(userId);

    res.json({
      success: true,
      message: 'Device updated',
      devices
    });

  } catch (error) {
    console.error('Update device error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update device'
    });
  }
});

// ============================================
// DELETE /api/users/devices/:id — Remove device
// ============================================
router.delete('/devices/:id', authenticate, (req, res) => {
  try {
    const userId = req.user.id;
    const deviceId = req.params.id;

    // Verify device belongs to user
    const device = db.prepare('SELECT * FROM devices WHERE id = ? AND user_id = ?')
      .get(deviceId, userId);

    if (!device) {
      return res.status(404).json({
        success: false,
        error: 'Device not found'
      });
    }

    // Delete device
    db.prepare('DELETE FROM devices WHERE id = ?').run(deviceId);

    logActivity(userId, 'device_removed', 'device', deviceId, `Device removed: ${device.device_name}`, req.ip);

    const devices = db.prepare('SELECT * FROM devices WHERE user_id = ? ORDER BY last_active DESC').all(userId);
    const deviceCount = getUserDeviceCount(userId);

    res.json({
      success: true,
      message: 'Device removed',
      devices,
      deviceLimit: {
        current: deviceCount,
        max: MAX_DEVICES,
        canAdd: deviceCount < MAX_DEVICES
      }
    });

  } catch (error) {
    console.error('Remove device error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to remove device'
    });
  }
});

// ============================================
// POST /api/users/devices/:id/refresh — Refresh device activity
// ============================================
router.post('/devices/:id/refresh', authenticate, (req, res) => {
  try {
    const userId = req.user.id;
    const deviceId = req.params.id;

    const device = db.prepare('SELECT * FROM devices WHERE id = ? AND user_id = ?')
      .get(deviceId, userId);

    if (!device) {
      return res.status(404).json({
        success: false,
        error: 'Device not found'
      });
    }

    db.prepare('UPDATE devices SET last_active = CURRENT_TIMESTAMP WHERE id = ?').run(deviceId);

    res.json({
      success: true,
      message: 'Device activity refreshed'
    });

  } catch (error) {
    console.error('Refresh device error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to refresh device'
    });
  }
});

module.exports = router;