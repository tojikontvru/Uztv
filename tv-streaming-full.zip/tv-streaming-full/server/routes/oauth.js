/**
 * SalomTV — OAuth Routes
 * Google and Yandex OAuth handling
 */

const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { db, getUserDeviceCount } = require('../database');
const { generateToken, guestOnly, logActivity } = require('../middleware/auth');

const router = express.Router();

// Google OAuth configuration
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || '';
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET || '';
const GOOGLE_REDIRECT_URI = process.env.GOOGLE_REDIRECT_URI || 'http://localhost:3000/api/oauth/google/callback';

// Yandex OAuth configuration
const YANDEX_CLIENT_ID = process.env.YANDEX_CLIENT_ID || '';
const YANDEX_CLIENT_SECRET = process.env.YANDEX_CLIENT_SECRET || '';
const YANDEX_REDIRECT_URI = process.env.YANDEX_REDIRECT_URI || 'http://localhost:3000/api/oauth/yandex/callback';

// ============================================
// GET /api/oauth/google — Initiate Google OAuth
// ============================================
router.get('/google', (req, res) => {
  const scope = encodeURIComponent('email profile');
  const redirectUri = encodeURIComponent(GOOGLE_REDIRECT_URI);

  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${GOOGLE_CLIENT_ID}&redirect_uri=${redirectUri}&response_type=code&scope=${scope}&access_type=offline`;

  res.json({
    success: true,
    auth_url: authUrl
  });
});

// ============================================
// GET /api/oauth/google/callback — Google OAuth Callback
// ============================================
router.get('/google/callback', guestOnly, async (req, res) => {
  try {
    const { code } = req.query;

    if (!code) {
      return res.status(400).json({
        success: false,
        error: 'Authorization code required'
      });
    }

    // Exchange code for tokens
    const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: GOOGLE_CLIENT_ID,
        client_secret: GOOGLE_CLIENT_SECRET,
        code,
        grant_type: 'authorization_code',
        redirect_uri: GOOGLE_REDIRECT_URI
      })
    });

    const tokens = await tokenResponse.json();

    if (tokens.error) {
      throw new Error(tokens.error_description || tokens.error);
    }

    // Get user info
    const userResponse = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: { 'Authorization': `Bearer ${tokens.access_token}` }
    });

    const googleUser = await userResponse.json();

    // Process user
    const result = await processOAuthUser('google', googleUser.id, googleUser.email, googleUser.name, googleUser.picture);

    // Redirect with token
    const redirectUrl = new URL('/login', `http://${req.get('host')}`);
    redirectUrl.searchParams.set('oauth_success', 'true');
    redirectUrl.searchParams.set('token', result.token);
    redirectUrl.searchParams.set('user', JSON.stringify(result.user));

    res.redirect(redirectUrl.toString());

  } catch (error) {
    console.error('Google OAuth error:', error);
    res.redirect('/login?oauth_error=google_failed');
  }
});

// ============================================
// GET /api/oauth/yandex — Initiate Yandex OAuth
// ============================================
router.get('/yandex', (req, res) => {
  const redirectUri = encodeURIComponent(YANDEX_REDIRECT_URI);

  const authUrl = `https://oauth.yandex.ru/authorize?client_id=${YANDEX_CLIENT_ID}&response_type=code&redirect_uri=${redirectUri}`;

  res.json({
    success: true,
    auth_url: authUrl
  });
});

// ============================================
// GET /api/oauth/yandex/callback — Yandex OAuth Callback
// ============================================
router.get('/yandex/callback', guestOnly, async (req, res) => {
  try {
    const { code } = req.query;

    if (!code) {
      return res.status(400).json({
        success: false,
        error: 'Authorization code required'
      });
    }

    // Exchange code for token
    const tokenResponse = await fetch('https://oauth.yandex.ru/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: YANDEX_CLIENT_ID,
        client_secret: YANDEX_CLIENT_SECRET,
        code,
        grant_type: 'authorization_code',
        redirect_uri: YANDEX_REDIRECT_URI
      })
    });

    const tokens = await tokenResponse.json();

    if (tokens.error) {
      throw new Error(tokens.error_description || tokens.error);
    }

    // Get user info
    const userResponse = await fetch('https://login.yandex.ru/info?format=json', {
      headers: { 'Authorization': `Bearer ${tokens.access_token}` }
    });

    const yandexUser = await userResponse.json();

    // Process user
    const result = await processOAuthUser('yandex', yandexUser.id, yandexUser.default_email, yandexUser.display_name || yandexUser.first_name, yandexUser.default_avatar_id ? `https://avatars.yandex.net/get-yap/${yandexUser.default_avatar_id}/normal` : null);

    // Redirect with token
    const redirectUrl = new URL('/login', `http://${req.get('host')}`);
    redirectUrl.searchParams.set('oauth_success', 'true');
    redirectUrl.searchParams.set('token', result.token);
    redirectUrl.searchParams.set('user', JSON.stringify(result.user));

    res.redirect(redirectUrl.toString());

  } catch (error) {
    console.error('Yandex OAuth error:', error);
    res.redirect('/login?oauth_error=yandex_failed');
  }
});

// ============================================
// POST /api/oauth/verify — Verify OAuth token from frontend
// ============================================
router.post('/verify', guestOnly, async (req, res) => {
  try {
    const { provider, access_token } = req.body;

    if (!provider || !access_token) {
      return res.status(400).json({
        success: false,
        error: 'Provider and access_token are required'
      });
    }

    let oauthUser = null;

    if (provider === 'google') {
      const response = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
        headers: { 'Authorization': `Bearer ${access_token}` }
      });
      oauthUser = await response.json();
      oauthUser.id = oauthUser.id;
    } else if (provider === 'yandex') {
      const response = await fetch('https://login.yandex.ru/info?format=json', {
        headers: { 'Authorization': `Bearer ${access_token}` }
      });
      oauthUser = await response.json();
    }

    if (!oauthUser || !oauthUser.id) {
      return res.status(401).json({
        success: false,
        error: 'Invalid access token'
      });
    }

    const result = await processOAuthUser(
      provider,
      oauthUser.id,
      oauthUser.email || oauthUser.default_email,
      oauthUser.name || oauthUser.display_name || oauthUser.first_name,
      oauthUser.picture || (oauthUser.default_avatar_id ? `https://avatars.yandex.net/get-yap/${oauthUser.default_avatar_id}/normal` : null)
    );

    res.json({
      success: true,
      token: result.token,
      user: result.user,
      deviceLimit: result.deviceLimit
    });

  } catch (error) {
    console.error('OAuth verify error:', error);
    res.status(500).json({
      success: false,
      error: 'OAuth verification failed'
    });
  }
});

// Helper function to process OAuth user
async function processOAuthUser(provider, oauth_id, email, username, avatar) {
  // Find existing user
  let user = db.prepare('SELECT * FROM users WHERE oauth_provider = ? AND oauth_id = ?')
    .get(provider, oauth_id);

  // If not found, check by email
  if (!user && email) {
    user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase());

    if (user) {
      db.prepare('UPDATE users SET oauth_provider = ?, oauth_id = ?, avatar = COALESCE(?, avatar) WHERE id = ?')
        .run(provider, oauth_id, avatar, user.id);
    }
  }

  // If still not found, create new user
  if (!user) {
    const userId = uuidv4();
    const generatedUsername = username || email?.split('@')[0] || `user_${oauth_id.slice(0, 8)}`;

    db.prepare(`
      INSERT INTO users (id, username, email, oauth_provider, oauth_id, avatar, role)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(userId, generatedUsername.toLowerCase(), email?.toLowerCase() || `${oauth_id}@${provider}.placeholder`, provider, oauth_id, avatar, 'user');

    user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
    logActivity(userId, 'oauth_register', 'user', userId, `Registered via ${provider}`, 'oauth');
  }

  const token = generateToken(user);
  const deviceCount = getUserDeviceCount(user.id);

  logActivity(user.id, 'oauth_login', 'user', user.id, `Logged in via ${provider}`, 'oauth');

  return {
    token,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      preferred_language: user.preferred_language,
      avatar: user.avatar
    },
    deviceLimit: {
      current: deviceCount,
      max: 3
    }
  };
}

module.exports = router;