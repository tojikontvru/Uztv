/**
 * SalomTV — Users Routes
 * User profile, favorites, watch history, device management
 */

const express = require('express');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { db, getUserDeviceCount } = require('../database');
const { authenticate, requireAdmin, logActivity } = require('../middleware/auth');

const router = express.Router();
const MAX_DEVICES = 3;

// ============================================
// GET /api/users — List users (Admin)
// ============================================
router.get('/', authenticate, requireAdmin, (req, res) => {
  try {
    const { page = 1, limit = 20, search, role } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let query = 'SELECT id, username, email, role, created_at, updated_at FROM users WHERE 1=1';
    let countQuery = 'SELECT COUNT(*) as total FROM users WHERE 1=1';
    const params = [];
    const countParams = [];

    if (role) {
      query += ' AND role = ?';
      countQuery += ' AND role = ?';
      params.push(role);
      countParams.push(role);
    }

    if (search) {
      query += ' AND (username LIKE ? OR email LIKE ?)';
      countQuery += ' AND (username LIKE ? OR email LIKE ?)';
      const searchPattern = `%${search}%`;
      params.push(searchPattern, searchPattern);
      countParams.push(searchPattern, searchPattern);
    }

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), offset);

    const users = db.prepare(query).all(...params);
    const total = db.prepare(countQuery).get(...countParams).total;

    res.json({
      success: true,
      users,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });

  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// ============================================
// GET /api/users/me/devices — Get user devices
// ============================================
router.get('/me/devices', authenticate, (req, res) => {
  try {
    const userId = req.user.id;

    const devices = db.prepare(`
      SELECT id, device_name, device_type, device_id, last_active, ip_address, user_agent, created_at
      FROM devices
      WHERE user_id = ?
      ORDER BY last_active DESC
    `).all(userId);

    const deviceCount = getUserDeviceCount(userId);

    res.json({
      success: true,
      devices,
      deviceLimit: {
        current: deviceCount,
        max: MAX_DEVICES,
        canAdd: deviceCount < MAX_DEVICES
      }
    });

  } catch (error) {
    console.error('Get devices error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get devices'
    });
  }
});

// ============================================
// POST /api/users/me/devices — Register new device
// ============================================
router.post('/me/devices', authenticate, (req, res) => {
  try {
    const userId = req.user.id;
    const { device_name, device_type, device_id, ip_address, user_agent } = req.body;

    if (!device_id) {
      return res.status(400).json({
        success: false,
        error: 'Device ID is required'
      });
    }

    const currentCount = getUserDeviceCount(userId);
    if (currentCount >= MAX_DEVICES) {
      return res.status(403).json({
        success: false,
        error: `Maximum device limit reached (${MAX_DEVICES}). Please remove a device to add a new one.`,
        deviceLimit: {
          current: currentCount,
          max: MAX_DEVICES
        }
      });
    }

    const existingDevice = db.prepare('SELECT id FROM devices WHERE user_id = ? AND device_id = ?')
      .get(userId, device_id);

    if (existingDevice) {
      db.prepare('UPDATE devices SET last_active = CURRENT_TIMESTAMP, ip_address = ?, user_agent = ? WHERE id = ?')
        .run(ip_address, user_agent, existingDevice.id);
    } else {
      const deviceDbId = uuidv4();
      db.prepare(`
        INSERT INTO devices (id, user_id, device_name, device_type, device_id, ip_address, user_agent)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).run(deviceDbId, userId, device_name || 'Unknown Device', device_type || 'web', device_id, ip_address, user_agent);

      logActivity(userId, 'device_added', 'device', deviceDbId, `Device registered: ${device_name}`, ip_address);
    }

    const devices = db.prepare('SELECT * FROM devices WHERE user_id = ? ORDER BY last_active DESC').all(userId);
    const deviceCount = getUserDeviceCount(userId);

    res.json({
      success: true,
      message: 'Device registered successfully',
      devices,
      deviceLimit: {
        current: deviceCount,
        max: MAX_DEVICES,
        canAdd: deviceCount < MAX_DEVICES
      }
    });

  } catch (error) {
    console.error('Register device error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to register device'
    });
  }
});

// ============================================
// DELETE /api/users/me/devices/:id — Remove device
// ============================================
router.delete('/me/devices/:id', authenticate, (req, res) => {
  try {
    const userId = req.user.id;
    const deviceId = req.params.id;

    const device = db.prepare('SELECT * FROM devices WHERE id = ? AND user_id = ?')
      .get(deviceId, userId);

    if (!device) {
      return res.status(404).json({
        success: false,
        error: 'Device not found'
      });
    }

    db.prepare('DELETE FROM devices WHERE id = ?').run(deviceId);

    logActivity(userId, 'device_removed', 'device', deviceId, `Device removed: ${device.device_name}`, req.ip);

    const devices = db.prepare('SELECT * FROM devices WHERE user_id = ? ORDER BY last_active DESC').all(userId);
    const deviceCount = getUserDeviceCount(userId);

    res.json({
      success: true,
      message: 'Device removed',
      devices,
      deviceLimit: {
        current: deviceCount,
        max: MAX_DEVICES,
        canAdd: deviceCount < MAX_DEVICES
      }
    });

  } catch (error) {
    console.error('Remove device error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to remove device'
    });
  }
});

// ============================================
// GET /api/users/me/favorites — Get user favorites
// ============================================
router.get('/me/favorites', authenticate, (req, res) => {
  try {
    const userId = req.user.id;

    const favorites = db.prepare(`
      SELECT c.*, f.created_at as favorited_at
      FROM favorites f
      JOIN channels c ON f.channel_id = c.id
      WHERE f.user_id = ?
      ORDER BY f.created_at DESC
    `).all(userId);

    res.json({
      success: true,
      favorites
    });

  } catch (error) {
    console.error('Get favorites error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get favorites'
    });
  }
});

// ============================================
// POST /api/users/me/favorites — Add to favorites
// ============================================
router.post('/me/favorites', authenticate, (req, res) => {
  try {
    const userId = req.user.id;
    const { channel_id } = req.body;

    if (!channel_id) {
      return res.status(400).json({
        success: false,
        error: 'Channel ID is required'
      });
    }

    const channel = db.prepare('SELECT id FROM channels WHERE id = ?').get(channel_id);
    if (!channel) {
      return res.status(404).json({
        success: false,
        error: 'Channel not found'
      });
    }

    db.prepare(`
      INSERT OR IGNORE INTO favorites (user_id, channel_id)
      VALUES (?, ?)
    `).run(userId, channel_id);

    logActivity(userId, 'favorite_added', 'channel', channel_id, 'Added to favorites', req.ip);

    const favorites = db.prepare(`
      SELECT c.*, f.created_at as favorited_at
      FROM favorites f
      JOIN channels c ON f.channel_id = c.id
      WHERE f.user_id = ?
      ORDER BY f.created_at DESC
    `).all(userId);

    res.json({
      success: true,
      message: 'Added to favorites',
      favorites
    });

  } catch (error) {
    console.error('Add favorite error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to add to favorites'
    });
  }
});

// ============================================
// DELETE /api/users/me/favorites/:channelId — Remove from favorites
// ============================================
router.delete('/me/favorites/:channelId', authenticate, (req, res) => {
  try {
    const userId = req.user.id;
    const channelId = req.params.channelId;

    db.prepare('DELETE FROM favorites WHERE user_id = ? AND channel_id = ?')
      .run(userId, channelId);

    logActivity(userId, 'favorite_removed', 'channel', channelId, 'Removed from favorites', req.ip);

    const favorites = db.prepare(`
      SELECT c.*, f.created_at as favorited_at
      FROM favorites f
      JOIN channels c ON f.channel_id = c.id
      WHERE f.user_id = ?
      ORDER BY f.created_at DESC
    `).all(userId);

    res.json({
      success: true,
      message: 'Removed from favorites',
      favorites
    });

  } catch (error) {
    console.error('Remove favorite error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to remove from favorites'
    });
  }
});

// ============================================
// GET /api/users/me/history — Get watch history
// ============================================
router.get('/me/history', authenticate, (req, res) => {
  try {
    const userId = req.user.id;
    const limit = parseInt(req.query.limit) || 50;

    const history = db.prepare(`
      SELECT c.*, w.watched_at, w.duration
      FROM watch_history w
      JOIN channels c ON w.channel_id = c.id
      WHERE w.user_id = ?
      ORDER BY w.watched_at DESC
      LIMIT ?
    `).all(userId, limit);

    res.json({
      success: true,
      history
    });

  } catch (error) {
    console.error('Get history error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get history'
    });
  }
});

// ============================================
// POST /api/users/me/history — Add to watch history
// ============================================
router.post('/me/history', authenticate, (req, res) => {
  try {
    const userId = req.user.id;
    const { channel_id, duration } = req.body;

    if (!channel_id) {
      return res.status(400).json({
        success: false,
        error: 'Channel ID is required'
      });
    }

    const channel = db.prepare('SELECT id FROM channels WHERE id = ?').get(channel_id);
    if (!channel) {
      return res.status(404).json({
        success: false,
        error: 'Channel not found'
      });
    }

    db.prepare(`
      INSERT INTO watch_history (user_id, channel_id, duration)
      VALUES (?, ?, ?)
    `).run(userId, channel_id, duration || 0);

    res.json({
      success: true,
      message: 'Added to watch history'
    });

  } catch (error) {
    console.error('Add history error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to add to history'
    });
  }
});

// ============================================
// DELETE /api/users/me/history — Clear watch history
// ============================================
router.delete('/me/history', authenticate, (req, res) => {
  try {
    const userId = req.user.id;

    db.prepare('DELETE FROM watch_history WHERE user_id = ?').run(userId);

    logActivity(userId, 'history_cleared', 'user', userId, 'Watch history cleared', req.ip);

    res.json({
      success: true,
      message: 'Watch history cleared'
    });

  } catch (error) {
    console.error('Clear history error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to clear history'
    });
  }
});

// ============================================
// GET /api/users/:id — Get user by ID (Admin)
// ============================================
router.get('/:id', authenticate, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;

    const user = db.prepare('SELECT id, username, email, role, created_at, updated_at FROM users WHERE id = ?').get(id);

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    const activity = db.prepare('SELECT * FROM activity_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 10').all(id);

    res.json({
      success: true,
      user,
      activity
    });

  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// ============================================
// PUT /api/users/:id/role — Change role (Admin)
// ============================================
router.put('/:id/role', authenticate, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;
    const { role } = req.body;

    if (id === req.user.id) {
      return res.status(400).json({
        success: false,
        error: 'Cannot change your own role'
      });
    }

    if (!['user', 'admin'].includes(role)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid role'
      });
    }

    const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    db.prepare('UPDATE users SET role = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(role, id);

    logActivity(req.user.id, 'change_role', 'user', id, `Changed role to ${role}`, req.ip);

    const user = db.prepare('SELECT id, username, email, role, created_at, updated_at FROM users WHERE id = ?').get(id);

    res.json({
      success: true,
      message: `Role changed to ${role === 'admin' ? 'admin' : 'user'}`,
      user
    });

  } catch (error) {
    console.error('Change role error:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// ============================================
// DELETE /api/users/:id — Delete user (Admin)
// ============================================
router.delete('/:id', authenticate, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;

    if (id === req.user.id) {
      return res.status(400).json({
        success: false,
        error: 'Cannot delete yourself'
      });
    }

    const existing = db.prepare('SELECT username, role FROM users WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    if (existing.role === 'admin') {
      const adminCount = db.prepare('SELECT COUNT(*) as count FROM users WHERE role = ?').get('admin').count;
      if (adminCount <= 1) {
        return res.status(400).json({
          success: false,
          error: 'Cannot delete the last admin'
        });
      }
    }

    db.prepare('DELETE FROM users WHERE id = ?').run(id);

    logActivity(req.user.id, 'delete', 'user', id, `Deleted user: ${existing.username}`, req.ip);

    res.json({
      success: true,
      message: 'User deleted'
    });

  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// ============================================
// GET /api/users/stats/overview — Statistics (Admin)
// ============================================
router.get('/stats/overview', authenticate, requireAdmin, (req, res) => {
  try {
    const totalUsers = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
    const totalAdmins = db.prepare('SELECT COUNT(*) as count FROM users WHERE role = ?').get('admin').count;
    const totalChannels = db.prepare('SELECT COUNT(*) as count FROM channels').get().count;
    const activeChannels = db.prepare('SELECT COUNT(*) as count FROM channels WHERE status = 1').get().count;
    const totalCategories = db.prepare('SELECT COUNT(*) as count FROM categories').get().count;

    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
    const newUsersWeek = db.prepare('SELECT COUNT(*) as count FROM users WHERE created_at > ?').get(weekAgo).count;

    const recentActivity = db.prepare(`
      SELECT al.*, u.username
      FROM activity_logs al
      LEFT JOIN users u ON al.user_id = u.id
      ORDER BY al.created_at DESC
      LIMIT 10
    `).all();

    res.json({
      success: true,
      stats: {
        users: {
          total: totalUsers,
          admins: totalAdmins,
          newThisWeek: newUsersWeek
        },
        channels: {
          total: totalChannels,
          active: activeChannels,
          inactive: totalChannels - activeChannels
        },
        categories: {
          total: totalCategories
        },
        recentActivity
      }
    });

  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

module.exports = router;