/**
 * SalomTV — Authentication Routes
 * Registration, Login, Profile, OAuth
 */

const express = require('express');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { db, getUserDeviceCount } = require('../database');
const { generateToken, authenticate, guestOnly, logActivity } = require('../middleware/auth');

const router = express.Router();

// ============================================
// POST /api/auth/register — Registration
// ============================================
router.post('/register', guestOnly, (req, res) => {
  try {
    const { username, email, password } = req.body;

    // Validation
    if (!username || !email || !password) {
      return res.status(400).json({
        success: false,
        error: 'All fields are required'
      });
    }

    if (username.length < 3 || username.length > 30) {
      return res.status(400).json({
        success: false,
        error: 'Username: 3-30 characters'
      });
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid email'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        error: 'Password minimum 6 characters'
      });
    }

    // Check existence
    const existingUser = db.prepare('SELECT id FROM users WHERE email = ? OR username = ?')
      .get(email.toLowerCase(), username.toLowerCase());

    if (existingUser) {
      return res.status(400).json({
        success: false,
        error: 'User with this email or username already exists'
      });
    }

    // Create user
    const hashedPassword = bcrypt.hashSync(password, 10);
    const userId = uuidv4();

    db.prepare(`
      INSERT INTO users (id, username, email, password, role)
      VALUES (?, ?, ?, ?, ?)
    `).run(userId, username.toLowerCase(), email.toLowerCase(), hashedPassword, 'user');

    const user = db.prepare('SELECT id, username, email, role, preferred_language, avatar FROM users WHERE id = ?').get(userId);
    const token = generateToken(user);

    logActivity(userId, 'register', 'user', userId, 'New user registration', req.ip);

    res.status(201).json({
      success: true,
      message: 'Registration successful',
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        preferred_language: user.preferred_language,
        avatar: user.avatar
      }
    });

  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// ============================================
// POST /api/auth/login — Login
// ============================================
router.post('/login', guestOnly, (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Email and password are required'
      });
    }

    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase());

    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'Invalid email or password'
      });
    }

    if (!user.password) {
      return res.status(401).json({
        success: false,
        error: 'This account uses OAuth login. Please use the same provider.'
      });
    }

    if (!bcrypt.compareSync(password, user.password)) {
      return res.status(401).json({
        success: false,
        error: 'Invalid email or password'
      });
    }

    const deviceCount = getUserDeviceCount(user.id);
    const maxDevices = 3;

    const token = generateToken(user);

    logActivity(user.id, 'login', 'user', user.id, 'User logged in', req.ip);

    res.json({
      success: true,
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        preferred_language: user.preferred_language,
        avatar: user.avatar
      },
      deviceLimit: {
        current: deviceCount,
        max: maxDevices
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// ============================================
// POST /api/auth/oauth — OAuth Login/Register
// ============================================
router.post('/oauth', guestOnly, (req, res) => {
  try {
    const { provider, oauth_id, email, username, avatar } = req.body;

    if (!provider || !oauth_id) {
      return res.status(400).json({
        success: false,
        error: 'Provider and oauth_id are required'
      });
    }

    // Find existing user
    let user = db.prepare('SELECT * FROM users WHERE oauth_provider = ? AND oauth_id = ?')
      .get(provider, oauth_id);

    // If not found, check by email
    if (!user && email) {
      user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase());

      // Link OAuth if email matches
      if (user) {
        db.prepare('UPDATE users SET oauth_provider = ?, oauth_id = ?, avatar = COALESCE(?, avatar) WHERE id = ?')
          .run(provider, oauth_id, avatar, user.id);
      }
    }

    // If still not found, create new user
    if (!user) {
      const userId = uuidv4();
      const generatedUsername = username || email?.split('@')[0] || `user_${oauth_id.slice(0, 8)}`;

      db.prepare(`
        INSERT INTO users (id, username, email, oauth_provider, oauth_id, avatar, role)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).run(userId, generatedUsername.toLowerCase(), email?.toLowerCase() || `${oauth_id}@${provider}.placeholder`, provider, oauth_id, avatar, 'user');

      user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
      logActivity(userId, 'oauth_register', 'user', userId, `Registered via ${provider}`, req.ip);
    }

    const token = generateToken(user);
    const deviceCount = getUserDeviceCount(user.id);

    logActivity(user.id, 'oauth_login', 'user', user.id, `Logged in via ${provider}`, req.ip);

    res.json({
      success: true,
      message: 'OAuth login successful',
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        preferred_language: user.preferred_language,
        avatar: user.avatar
      },
      deviceLimit: {
        current: deviceCount,
        max: 3
      }
    });

  } catch (error) {
    console.error('OAuth error:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// ============================================
// GET /api/auth/me — Current User
// ============================================
router.get('/me', authenticate, (req, res) => {
  const user = db.prepare('SELECT id, username, email, role, preferred_language, avatar, created_at FROM users WHERE id = ?')
    .get(req.user.id);

  const deviceCount = getUserDeviceCount(req.user.id);

  res.json({
    success: true,
    user: {
      ...user,
      deviceLimit: {
        current: deviceCount,
        max: 3
      }
    }
  });
});

// ============================================
// PUT /api/auth/password — Change Password
// ============================================
router.put('/password', authenticate, (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const userId = req.user.id;

    const user = db.prepare('SELECT password FROM users WHERE id = ?').get(userId);

    if (!user.password) {
      return res.status(400).json({
        success: false,
        error: 'No password set for this account'
      });
    }

    if (!bcrypt.compareSync(currentPassword, user.password)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid current password'
      });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({
        success: false,
        error: 'New password minimum 6 characters'
      });
    }

    const hashedPassword = bcrypt.hashSync(newPassword, 10);
    db.prepare('UPDATE users SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(hashedPassword, userId);

    logActivity(userId, 'password_change', 'user', userId, 'Password changed', req.ip);

    res.json({
      success: true,
      message: 'Password changed successfully'
    });

  } catch (error) {
    console.error('Password change error:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// ============================================
// PUT /api/auth/profile — Update Profile
// ============================================
router.put('/profile', authenticate, (req, res) => {
  try {
    const { username, email, preferred_language, avatar } = req.body;
    const userId = req.user.id;

    // Check uniqueness
    if (username || email) {
      const existing = db.prepare(`
        SELECT id FROM users
        WHERE (username = ? OR email = ?) AND id != ?
      `).get(
        username?.toLowerCase() || '',
        email?.toLowerCase() || '',
        userId
      );

      if (existing) {
        return res.status(400).json({
          success: false,
          error: 'Username or email already taken'
        });
      }
    }

    // Update
    const updates = [];
    const values = [];

    if (username) {
      updates.push('username = ?');
      values.push(username.toLowerCase());
    }
    if (email) {
      updates.push('email = ?');
      values.push(email.toLowerCase());
    }
    if (preferred_language) {
      updates.push('preferred_language = ?');
      values.push(preferred_language);
    }
    if (avatar !== undefined) {
      updates.push('avatar = ?');
      values.push(avatar);
    }

    if (updates.length > 0) {
      updates.push('updated_at = CURRENT_TIMESTAMP');
      values.push(userId);

      db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...values);
    }

    const updatedUser = db.prepare('SELECT id, username, email, role, preferred_language, avatar FROM users WHERE id = ?').get(userId);

    logActivity(userId, 'profile_update', 'user', userId, 'Profile updated', req.ip);

    res.json({
      success: true,
      message: 'Profile updated',
      user: updatedUser
    });

  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// ============================================
// DELETE /api/auth/account — Delete Account
// ============================================
router.delete('/account', authenticate, (req, res) => {
  try {
    const userId = req.user.id;

    // Delete all user data
    db.prepare('DELETE FROM watch_history WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM favorites WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM devices WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM users WHERE id = ?').run(userId);

    logActivity(userId, 'account_delete', 'user', userId, 'Account deleted', req.ip);

    res.json({
      success: true,
      message: 'Account deleted successfully'
    });

  } catch (error) {
    console.error('Account delete error:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

module.exports = router;