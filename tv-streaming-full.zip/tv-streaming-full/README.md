# SalomTV Platform

Многофункциональная платформа для TV-стриминга с поддержкой OAuth авторизации (Google + Яндекс), мультиязычностью и управлением устройствами.

## Функции

- **OAuth Авторизация**: Google и Яндекс вход
- **Мультиязычность**: RU, UZ, TJ, EN
- **Управление устройствами**: до 3 устройств на аккаунт
- **Личный кабинет**: профиль, избранное, история просмотров
- **Админ-панель**: управление пользователями и каналами
- **Современный UI**: тёмная тема, плавные анимации

---

## Установка Web-сервера

### Требования

- Node.js 18+
- npm или yarn

### Шаги установки

```bash
# 1. Перейти в директорию проекта
cd tv-streaming-full

# 2. Установить зависимости
npm install

# 3. Запустить сервер
npm start
```

Сервер запустится на `http://localhost:3000`

### Конфигурация (.env)

Создайте файл `.env` в корне проекта:

```env
# Server
PORT=3000

# JWT Secret ( ОБЯЗАТЕЛЬНО изменить в продакшене! )
JWT_SECRET=your-super-secret-key-change-this

# OAuth Google
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret
GOOGLE_REDIRECT_URI=http://localhost:3000/api/oauth/google/callback

# OAuth Yandex
YANDEX_CLIENT_ID=your-yandex-client-id
YANDEX_CLIENT_SECRET=your-yandex-client-secret
YANDEX_REDIRECT_URI=http://localhost:3000/api/oauth/yandex/callback
```

### Получение OAuth credentials

#### Google OAuth:

1. Перейдите на [Google Cloud Console](https://console.cloud.google.com/)
2. Создайте новый проект
3. APIs & Services → Credentials → Create Credentials → OAuth Client ID
4. Тип: Web application
5. Добавьте redirect URI: `http://localhost:3000/api/oauth/google/callback`

#### Yandex OAuth:

1. Перейдите на [Yandex OAuth](https://oauth.yandex.com/)
2. Создайте приложение
3. Тип: Web application
4. Добавьте redirect URI: `http://localhost:3000/api/oauth/yandex/callback`

---

## Структура API

### Auth Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Регистрация |
| POST | `/api/auth/login` | Вход |
| POST | `/api/auth/oauth` | OAuth вход |
| GET | `/api/auth/me` | Текущий пользователь |
| PUT | `/api/auth/profile` | Обновить профиль |
| PUT | `/api/auth/password` | Изменить пароль |
| DELETE | `/api/auth/account` | Удалить аккаунт |

### User Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/users/me/devices` | Список устройств |
| POST | `/api/users/me/devices` | Добавить устройство |
| DELETE | `/api/users/me/devices/:id` | Удалить устройство |
| GET | `/api/users/me/favorites` | Избранное |
| POST | `/api/users/me/favorites` | Добавить в избранное |
| DELETE | `/api/users/me/favorites/:channelId` | Удалить из избранного |
| GET | `/api/users/me/history` | История просмотров |
| POST | `/api/users/me/history` | Добавить в историю |
| DELETE | `/api/users/me/history` | Очистить историю |

### OAuth Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/oauth/google` | Инициализация Google OAuth |
| GET | `/api/oauth/google/callback` | Google callback |
| GET | `/api/oauth/yandex` | Инициализация Yandex OAuth |
| GET | `/api/oauth/yandex/callback` | Yandex callback |
| POST | `/api/oauth/verify` | Проверка OAuth токена |

---

## Сборка для продакшена

```bash
# Сборка клиента (если есть)
npm run build

# Запуск в фоне
pm2 start server/index.js --name salomtv

# или с nohup
nohup npm start > server.log &
```

---

## Android-приложение

### Обновление API URL

В файле `ApiService.kt` измените:

```kotlin
companion object {
    const val BASE_URL = "http://YOUR_SERVER_IP:3000/api/"
}
```

Замените `YOUR_SERVER_IP` на реальный IP вашего сервера.

### Сборка APK

```bash
cd android-app
./gradlew assembleDebug
```

APK будет в: `app/build/outputs/apk/debug/app-debug.apk`

---

## Лимит устройств

- По умолчанию каждый аккаунт поддерживает **до 3 устройств**
- При превышении лимита необходимо удалить одно устройство
- Устройства автоматически отслеживаются по уникальному device_id

---

## Языки интерфейса

Поддерживаемые языки:
- 🇷🇺 **Русский (ru)** - по умолчанию
- 🇺🇿 **Узбекский (uz)**
- 🇹🇯 **Таджикский (tj)**
- 🇬🇧 **Английский (en)**

Язык можно изменить в личном кабинете или через API.

---

## Дефолтные данные

### Админ-аккаунт

```
Email: admin@salomtv.uz
Password: admin123
```

**⚠️ ВАЖНО: Смените пароль после первого входа!**

---

## Troubleshooting

### Ошибка "OAuth not configured"

Проверьте, что вы добавили OAuth credentials в `.env` файл.

### Сервер не запускается

```bash
# Проверьте, что порт 3000 свободен
lsof -i :3000

# Или измените порт
PORT=3001 npm start
```

### Android не подключается к серверу

1. Убедитесь, что сервер запущен
2. Проверьте firewall: `iptables -L -n | grep 3000`
3. Измените URL в ApiService.kt на реальный IP сервера

---

## Лицензия

MIT License

---

## Контакты

Для поддержки и вопросов обращайтесь к команде разработки.