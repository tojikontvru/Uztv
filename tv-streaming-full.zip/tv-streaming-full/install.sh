#!/bin/bash

# ============================================================================
# SalomTV Full Platform — Installation Script
# Автоматическая установка на VDS сервер
# Версия: 2.0 (Исправленная)
# ============================================================================

set -e

# Цвета
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Конфигурация
WEB_ROOT="/var/www/salomtv"
NODE_VERSION="18"
DOMAIN=""
ADMIN_EMAIL="admin@salomtv.uz"
ADMIN_PASSWORD=""

# OAuth Configuration (опционально)
GOOGLE_CLIENT_ID=""
GOOGLE_CLIENT_SECRET=""
YANDEX_CLIENT_ID=""
YANDEX_CLIENT_SECRET=""

# Функции
print_step() { echo -e "\n${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"; }
print_success() { echo -e "${GREEN}✓ $1${NC}"; }
print_error() { echo -e "${RED}✗ $1${NC}"; }
print_info() { echo -e "${YELLOW}→ $1${NC}"; }
print_warning() { echo -e "${YELLOW}⚠️  $1${NC}"; }

# Обработка ошибок
error_exit() {
    print_error "$1"
    exit 1
}

# Заголовок
show_banner() {
    clear
    echo ""
    echo -e "${RED}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${RED}║${NC}"                                                              "${RED}║${NC}"
    echo -e "${RED}║${NC}  ${CYAN}███████╗███████╗ █████╗ ████████╗ ██████╗██╗  ██╗${NC}            ${RED}║${NC}"
    echo -e "${RED}║${NC}  ${CYAN}██╔════╝██╔════╝██╔══██╗╚══██╔══╝██╔════╝██║  ██║${NC}            ${RED}║${NC}"
    echo -e "${RED}║${NC}  ${CYAN}███████╗█████╗  ███████║   ██║   ██║     ███████║${NC}            ${RED}║${NC}"
    echo -e "${RED}║${NC}  ${CYAN}╚════██║██╔══╝  ██╔══██║   ██║   ██║     ██╔══██║${NC}            ${RED}║${NC}"
    echo -e "${RED}║${NC}  ${CYAN}███████║███████╗██║  ██║   ██║   ╚██████╗██║  ██║${NC}            ${RED}║${NC}"
    echo -e "${RED}║${NC}  ${CYAN}╚══════╝╚══════╝╚═╝  ╚═╝   ╚═╝    ╚═════╝╚═╝  ╚═╝${NC}            ${RED}║${NC}"
    echo -e "${RED}║${NC}"                                                              "${RED}║${NC}"
    echo -e "${RED}║${NC}         ${YELLOW}Full Platform + Admin Panel Installer v2.0${NC}         ${RED}║${NC}"
    echo -e "${RED}║${NC}"                                                              "${RED}║${NC}"
    echo -e "${RED}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# Проверка root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        error_exit "Запустите скрипт от root: sudo bash install.sh"
    fi
}

# Проверка зависимостей
check_prerequisites() {
    print_step
    echo -e "${CYAN}🔍 Проверка системы${NC}"
    
    # Проверка curl
    if ! command -v curl &> /dev/null; then
        print_info "Установка curl..."
        if command -v apt-get &> /dev/null; then
            apt-get install -y curl
        elif command -v yum &> /dev/null; then
            yum install -y curl
        fi
    fi
    
    # Проверка свободного места (минимум 2GB)
    AVAILABLE_SPACE=$(df / | awk 'NR==2 {print $4}')
    if [[ $AVAILABLE_SPACE -lt 2097152 ]]; then
        print_warning "Мало свободного места на диске (менее 2GB)"
        df -h /
    fi
    
    # Проверка памяти (минимум 1GB)
    TOTAL_MEM=$(free -m | awk 'NR==2 {print $2}')
    if [[ $TOTAL_MEM -lt 1024 ]]; then
        print_warning "Рекомендуется минимум 1GB RAM (доступно: ${TOTAL_MEM}MB)"
    fi
    
    print_success "Проверка системы завершена"
}

# Выбор домена
get_domain() {
    print_step
    echo -e "${CYAN}🌐 Настройка домена${NC}"
    echo ""
    echo -e "Введите доменное имя вашего сайта."
    echo -e "Пример: ${YELLOW}tv.example.com${NC}"
    echo ""
    
    while true; do
        read -p "Домен: " DOMAIN
        
        if [[ "$DOMAIN" =~ ^[a-zA-Z0-9][a-zA-Z0-9.-]*\.[a-zA-Z]{2,}$ ]]; then
            # Проверка DNS
            print_info "Проверка DNS для $DOMAIN..."
            if host "$DOMAIN" &> /dev/null; then
                DOMAIN_IP=$(host "$DOMAIN" | grep "has address" | head -1 | awk '{print $NF}')
                SERVER_IP=$(curl -s ifconfig.me)
                
                if [[ "$DOMAIN_IP" == "$SERVER_IP" ]]; then
                    print_success "DNS настроен корректно ($DOMAIN -> $SERVER_IP)"
                    break
                else
                    print_warning "DNS указывает на $DOMAIN_IP, а сервер имеет IP $SERVER_IP"
                    read -p "Продолжить всё равно? (y/n): " -n 1 -r
                    echo
                    if [[ $REPLY =~ ^[Yy]$ ]]; then
                        break
                    fi
                fi
            else
                print_warning "DNS запись для $DOMAIN не найдена"
                read -p "Продолжить всё равно? (y/n): " -n 1 -r
                echo
                if [[ $REPLY =~ ^[Yy]$ ]]; then
                    break
                fi
            fi
        else
            print_error "Некорректный формат домена!"
            echo -e "Пример корректного домена: ${YELLOW}tv.example.com${NC}"
        fi
    done
    
    print_success "Домен установлен: $DOMAIN"
}

# Настройка администратора
get_admin_credentials() {
    print_step
    echo -e "${CYAN}👤 Настройка администратора${NC}"
    echo ""

    # Email
    while true; do
        echo -e "Введите email администратора:"
        read -p "Email: " ADMIN_EMAIL
        
        if [[ "$ADMIN_EMAIL" =~ ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$ ]]; then
            break
        else
            print_error "Некорректный формат email!"
        fi
    done

    # Пароль
    echo ""
    echo -e "${YELLOW}⚠️  Внимание: используйте надёжный пароль!${NC}"
    
    while true; do
        read -s -p "Пароль (минимум 8 символов): " ADMIN_PASSWORD
        echo ""
        
        if [[ ${#ADMIN_PASSWORD} -ge 8 ]]; then
            read -s -p "Подтвердите пароль: " PASSWORD_CONFIRM
            echo ""
            
            if [[ "$ADMIN_PASSWORD" == "$PASSWORD_CONFIRM" ]]; then
                break
            else
                print_error "Пароли не совпадают!"
            fi
        else
            print_error "Пароль должен содержать минимум 8 символов!"
        fi
    done

    print_success "Данные администратора настроены"
    echo -e "   Email: ${GREEN}$ADMIN_EMAIL${NC}"
}

# Обновление системы
update_system() {
    print_step
    echo -e "${CYAN}📦 Обновление системы${NC}"
    
    if command -v apt-get &> /dev/null; then
        apt-get update -qq
        apt-get upgrade -y -qq
        print_success "Система обновлена (Debian/Ubuntu)"
    elif command -v yum &> /dev/null; then
        yum update -y -q
        print_success "Система обновлена (CentOS/RHEL)"
    fi
}

# Установка Node.js
install_nodejs() {
    print_step
    echo -e "${CYAN}📦 Установка Node.js $NODE_VERSION${NC}"
    
    if command -v node &> /dev/null; then
        NODE_CURRENT=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
        if [[ $NODE_CURRENT -ge $NODE_VERSION ]]; then
            print_info "Node.js уже установлен: $(node -v)"
            return
        fi
    fi
    
    if command -v apt-get &> /dev/null; then
        curl -fsSL https://deb.nodesource.com/setup_$NODE_VERSION.x | bash -
        apt-get install -y nodejs
    elif command -v yum &> /dev/null; then
        curl -fsSL https://rpm.nodesource.com/setup_$NODE_VERSION.x | bash -
        yum install -y nodejs
    fi
    
    print_success "Node.js $(node -v) установлен"
}

# Установка PM2
install_pm2() {
    print_step
    echo -e "${CYAN}📦 Установка PM2${NC}"
    
    if command -v pm2 &> /dev/null; then
        print_info "PM2 уже установлен"
    else
        npm install -g pm2
        pm2 startup systemd -u www-data --hp /var/www
        print_success "PM2 установлен"
    fi
}

# Установка Nginx
install_nginx() {
    print_step
    echo -e "${CYAN}📦 Установка Nginx${NC}"
    
    if command -v nginx &> /dev/null; then
        print_info "Nginx уже установлен"
        return
    fi
    
    if command -v apt-get &> /dev/null; then
        apt-get install -y nginx
    elif command -v yum &> /dev/null; then
        yum install -y nginx
    fi
    
    systemctl enable nginx
    systemctl start nginx
    print_success "Nginx установлен и запущен"
}

# Создание директории
create_directories() {
    print_step
    echo -e "${CYAN}📁 Создание директорий${NC}"
    
    mkdir -p "$WEB_ROOT"
    mkdir -p /var/log/salomtv
    mkdir -p /var/backups/salomtv
    
    print_success "Директории созданы"
}

# Копирование файлов
copy_files() {
    print_step
    echo -e "${CYAN}📁 Копирование файлов${NC}"

    # Определяем источник - текущая директория или /workspace
    if [[ -d "/workspace/tv-streaming-full" ]]; then
        SOURCE_DIR="/workspace/tv-streaming-full"
    else
        SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
    fi

    echo -e "Источник: ${YELLOW}$SOURCE_DIR${NC}"

    # Проверяем наличие необходимых файлов
    if [[ ! -f "$SOURCE_DIR/package.json" ]]; then
        error_exit "package.json не найден в $SOURCE_DIR"
    fi

    # Очищаем старую директорию если существует
    if [[ -d "$WEB_ROOT" ]]; then
        echo -e "${YELLOW}⚠️  Директория $WEB_ROOT уже существует${NC}"
        read -p "Очистить и переустановить? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            rm -rf "$WEB_ROOT"/*
            print_info "Директория очищена"
        else
            print_info "Используем существующую директорию"
        fi
    fi

    # Создаём директорию
    mkdir -p "$WEB_ROOT"

    # Копируем файлы с исключениями
    rsync -av --exclude='node_modules' \
              --exclude='.git' \
              --exclude='.env' \
              --exclude='*.log' \
              --exclude='.admin_config' \
              "$SOURCE_DIR"/ "$WEB_ROOT"/ || \
    cp -r "$SOURCE_DIR"/* "$WEB_ROOT/" 2>/dev/null || true

    # Права
    chown -R www-data:www-data "$WEB_ROOT"
    chmod -R 755 "$WEB_ROOT"
    chmod 600 "$WEB_ROOT/.env" 2>/dev/null || true

    print_success "Файлы скопированы в $WEB_ROOT"
}

# Установка зависимостей npm
install_npm_deps() {
    print_step
    echo -e "${CYAN}📦 Установка зависимостей${NC}"
    
    cd "$WEB_ROOT"
    
    # Очистка кэша npm если есть проблемы
    npm cache clean --force 2>/dev/null || true
    
    # Установка зависимостей
    npm install --production --no-audit --no-fund
    
    print_success "Зависимости установлены"
}

# Инициализация базы данных
init_database() {
    print_step
    echo -e "${CYAN}💾 Инициализация базы данных${NC}"

    cd "$WEB_ROOT"

    # Создаём файл с учётными данными администратора (временно)
    cat > "$WEB_ROOT/.admin_config" << EOF
ADMIN_EMAIL=$ADMIN_EMAIL
ADMIN_PASSWORD=$ADMIN_PASSWORD
EOF

    # Запускаем установку
    if npm run setup; then
        print_success "База данных инициализирована"
    else
        print_error "Ошибка инициализации базы данных"
        error_exit "Проверьте логи и попробуйте снова"
    fi
    
    # Удаляем временный файл с паролем
    rm -f "$WEB_ROOT/.admin_config"
}

# Создание временной Nginx конфигурации для получения SSL
create_temp_nginx_config() {
    print_step
    echo -e "${CYAN}⚙️  Создание временной конфигурации Nginx${NC}"
    
    cat > /etc/nginx/sites-available/salomtv << EOF
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN;
    
    root $WEB_ROOT/public;
    index index.html;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;

    # Gzip
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml application/json application/javascript;

    # Static files caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # Main app
    location / {
        try_files \$uri \$uri/ /index.html;
    }

    # API proxy to Node.js
    location /api/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }

    # Health check
    location /health {
        proxy_pass http://127.0.0.1:3000/health;
        access_log off;
    }

    # Logs
    access_log /var/log/nginx/salomtv_access.log;
    error_log /var/log/nginx/salomtv_error.log;
}
EOF

    # Активация
    rm -f /etc/nginx/sites-enabled/default
    ln -sf /etc/nginx/sites-available/salomtv /etc/nginx/sites-enabled/
    
    nginx -t && systemctl reload nginx
    
    print_success "Временная конфигурация Nginx создана"
}

# SSL сертификат
get_ssl() {
    print_step
    echo -e "${CYAN}🔒 Получение SSL сертификата${NC}"
    
    # Установка certbot
    if command -v apt-get &> /dev/null; then
        apt-get install -y certbot python3-certbot-nginx
    elif command -v yum &> /dev/null; then
        yum install -y certbot python3-certbot-nginx
    fi
    
    # Проверка доступности домена
    print_info "Проверка доступности http://$DOMAIN"
    if curl -s -o /dev/null -w "%{http_code}" "http://$DOMAIN" | grep -q "200\|301\|302"; then
        print_success "Сайт доступен"
    else
        print_warning "Сайт недоступен, но продолжаем"
    fi
    
    # Получение сертификата
    if certbot --nginx -d "$DOMAIN" \
               --non-interactive \
               --agree-tos \
               -m "$ADMIN_EMAIL" \
               --redirect \
               --hsts; then
        print_success "SSL сертификат получен и настроен"
    else
        print_error "Не удалось получить SSL сертификат"
        print_info "Попробуйте позже выполнить: certbot --nginx -d $DOMAIN"
    fi
}

# Финальная Nginx конфигурация с SSL
create_final_nginx_config() {
    print_step
    echo -e "${CYAN}⚙️  Обновление конфигурации Nginx${NC}"
    
    # Certbot уже создал конфигурацию с SSL, добавляем дополнительные настройки
    
    if [[ -f "/etc/nginx/sites-available/salomtv" ]]; then
        # Добавляем дополнительные заголовки безопасности
        sed -i '/server_name/a \    # Дополнительные заголовки безопасности\n    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;\n    add_header Content-Security-Policy "default-src https: data: 'unsafe-inline' 'unsafe-eval'" always;' /etc/nginx/sites-available/salomtv 2>/dev/null || true
        
        nginx -t && systemctl reload nginx
        print_success "Конфигурация Nginx обновлена"
    fi
}

# Systemd сервис
create_service() {
    print_step
    echo -e "${CYAN}⚙️  Создание systemd сервиса${NC}"
    
    cat > /etc/systemd/system/salomtv.service << EOF
[Unit]
Description=SalomTV Platform
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=$WEB_ROOT
Environment="NODE_ENV=production"
Environment="PORT=3000"
ExecStart=/usr/bin/node $WEB_ROOT/server/index.js
Restart=always
RestartSec=10
StandardOutput=append:/var/log/salomtv/app.log
StandardError=append:/var/log/salomtv/error.log

# Security
NoNewPrivileges=yes
PrivateTmp=yes
ProtectSystem=strict
ProtectHome=yes
ReadWritePaths=$WEB_ROOT /var/log/salomtv

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable salomtv
    systemctl start salomtv
    
    # Ждём запуска
    sleep 5
    
    if systemctl is-active --quiet salomtv; then
        print_success "Сервис создан и запущен"
    else
        print_error "Сервис не запустился"
        journalctl -u salomtv --no-pager -n 20
        error_exit "Проверьте логи и исправьте ошибки"
    fi
}

# Firewall
setup_firewall() {
    print_step
    echo -e "${CYAN}🛡️  Настройка firewall${NC}"
    
    if command -v ufw &> /dev/null; then
        ufw --force enable
        ufw allow 22/tcp comment 'SSH'
        ufw allow 80/tcp comment 'HTTP'
        ufw allow 443/tcp comment 'HTTPS'
        ufw reload
        print_success "UFW настроен"
    elif command -v firewall-cmd &> /dev/null; then
        systemctl start firewalld
        systemctl enable firewalld
        firewall-cmd --permanent --add-service=ssh
        firewall-cmd --permanent --add-service=http
        firewall-cmd --permanent --add-service=https
        firewall-cmd --reload
        print_success "Firewalld настроен"
    else
        print_info "Firewall не обнаружен, пропускаем"
    fi
}

# Создание скрипта резервного копирования
create_backup_script() {
    print_step
    echo -e "${CYAN}💾 Создание скрипта резервного копирования${NC}"
    
    cat > /usr/local/bin/salomtv-backup << 'EOF'
#!/bin/bash
BACKUP_DIR="/var/backups/salomtv"
DATE=$(date +%Y%m%d_%H%M%S)
WEB_ROOT="/var/www/salomtv"

mkdir -p "$BACKUP_DIR"

# Backup database
if [ -f "$WEB_ROOT/data/database.sqlite" ]; then
    cp "$WEB_ROOT/data/database.sqlite" "$BACKUP_DIR/database_$DATE.sqlite"
fi

# Backup config
if [ -f "$WEB_ROOT/.env" ]; then
    cp "$WEB_ROOT/.env" "$BACKUP_DIR/env_$DATE"
fi

# Clean old backups (keep 7 days)
find "$BACKUP_DIR" -type f -mtime +7 -delete

echo "Backup completed: $DATE"
EOF

    chmod +x /usr/local/bin/salomtv-backup
    
    # Добавление в cron
    (crontab -l 2>/dev/null; echo "0 2 * * * /usr/local/bin/salomtv-backup") | crontab -
    
    print_success "Скрипт резервного копирования создан"
}

# Финальная информация
show_info() {
    print_step
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║${NC}              ${GREEN}✅ УСТАНОВКА ЗАВЕРШЕНА УСПЕШНО!${NC}                   ${GREEN}║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${YELLOW}🌐 URL сайта:${NC}"
    echo -e "   ${GREEN}https://$DOMAIN${NC}"
    echo ""
    echo -e "${YELLOW}👤 Админ-панель:${NC}"
    echo -e "   ${GREEN}https://$DOMAIN/admin${NC}"
    echo ""
    echo -e "${YELLOW}📊 Управление сервисом:${NC}"
    echo -e "   Статус:     ${CYAN}sudo systemctl status salomtv${NC}"
    echo -e "   Перезапуск: ${CYAN}sudo systemctl restart salomtv${NC}"
    echo -e "   Логи:       ${CYAN}sudo journalctl -u salomtv -f${NC}"
    echo ""
    echo -e "${YELLOW}💾 Резервное копирование:${NC}"
    echo -e "   Ручное:     ${CYAN}sudo /usr/local/bin/salomtv-backup${NC}"
    echo -e "   Авто:       ${CYAN}ежедневно в 2:00${NC}"
    echo ""
    echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}👤 Данные администратора:${NC}"
    echo -e "   Email:    ${GREEN}$ADMIN_EMAIL${NC}"
    echo -e "   Пароль:   ${GREEN}********${NC} ${YELLOW}(введён при установке)${NC}"
    echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${YELLOW}📝 Важные файлы:${NC}"
    echo -e "   Конфиг Nginx: ${CYAN}/etc/nginx/sites-available/salomtv${NC}"
    echo -e "   Логи приложения: ${CYAN}/var/log/salomtv/${NC}"
    echo -e "   Данные: ${CYAN}$WEB_ROOT/data/${NC}"
    echo ""
    echo -e "${GREEN}🎉 Спасибо за использование SalomTV!${NC}"
    echo ""
    echo -e "${YELLOW}⚠️  Рекомендуется перезагрузить сервер: sudo reboot${NC}"
    echo ""
}

# Главная функция
main() {
    show_banner
    check_root
    check_prerequisites
    get_domain
    get_admin_credentials
    
    echo ""
    echo -e "${YELLOW}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${YELLOW}Начинается установка. Это может занять 5-10 минут.${NC}"
    echo -e "${YELLOW}════════════════════════════════════════════════════════════════${NC}"
    echo ""
    read -p "Нажмите Enter для продолжения..."
    
    update_system
    install_nodejs
    install_pm2
    install_nginx
    create_directories
    copy_files
    install_npm_deps
    init_database
    create_service
    create_temp_nginx_config
    get_ssl
    create_final_nginx_config
    setup_firewall
    create_backup_script
    
    show_info
}

# Запуск
main "$@"