#!/bin/bash

# ============================================================================
# SalomTV Full Platform — Installation Script
# Автоматическая установка на VDS сервер
# ============================================================================

set -e

# Цвета
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Конфигурация
WEB_ROOT="/var/www/salomtv"
NODE_VERSION="18"
DOMAIN=""
ADMIN_EMAIL="admin@salomtv.uz"
ADMIN_PASSWORD="admin123"

# Функции
print_step() { echo -e "\n${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"; }
print_success() { echo -e "${GREEN}✓ $1${NC}"; }
print_error() { echo -e "${RED}✗ $1${NC}"; }
print_info() { echo -e "${YELLOW}→ $1${NC}"; }

# Заголовок
show_banner() {
    clear
    echo ""
    echo -e "${RED}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${RED}║${NC}"                                                              "${RED}║${NC}"
    echo -e "${RED}║${NC}  ${CYAN}███████╗███████╗ █████╗ ████████╗ ██████╗██╗  ██╗${NC}            ${RED}║${NC}"
    echo -e "${RED}║${NC}  ${CYAN}██╔════╝██╔════╝██╔══██╗╚══██╔══╝██╔════╝██║  ██║${NC}            ${RED}║${NC}"
    echo -e "${RED}║${NC}  ${CYAN}███████╗█████╗  ███████║   ██║   ██║     ███████║${NC}            ${RED}║${NC}"
    echo -e "${RED}║${NC}  ${CYAN}╚════██║██╔══╝  ██╔══██║   ██║   ██║     ██╔══██║${NC}            ${RED}║${NC}"
    echo -e "${RED}║${NC}  ${CYAN}███████║███████╗██║  ██║   ██║   ╚██████╗██║  ██║${NC}            ${RED}║${NC}"
    echo -e "${RED}║${NC}  ${CYAN}╚══════╝╚══════╝╚═╝  ╚═╝   ╚═╝    ╚═════╝╚═╝  ╚═╝${NC}            ${RED}║${NC}"
    echo -e "${RED}║${NC}"                                                              "${RED}║${NC}"
    echo -e "${RED}║${NC}         ${YELLOW}Full Platform + Admin Panel Installer${NC}              ${RED}║${NC}"
    echo -e "${RED}║${NC}"                                                              "${RED}║${NC}"
    echo -e "${RED}╚══════════════════════════════════════════════════════════════╗${NC}"
    echo ""
}

# Проверка root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "Запустите скрипт от root: sudo bash install.sh"
        exit 1
    fi
}

# Выбор домена
get_domain() {
    print_step
    echo -e "${CYAN}🌐 Настройка домена${NC}"
    echo ""
    echo -e "Введите доменное имя вашего сайта."
    echo -e "Пример: ${YELLOW}tv.example.com${NC}"
    echo ""
    read -p "Домен: " DOMAIN

    # Проверка формата домена
    while [[ ! "$DOMAIN" =~ ^[a-zA-Z0-9][a-zA-Z0-9.-]*\.[a-zA-Z]{2,}$ ]]; do
        print_error "Некорректный формат домена!"
        echo -e "Пример корректного домена: ${YELLOW}tv.example.com${NC}"
        echo ""
        read -p "Домен: " DOMAIN
    done

    print_success "Домен установлен: $DOMAIN"
}

# Настройка администратора
get_admin_credentials() {
    print_step
    echo -e "${CYAN}👤 Настройка администратора${NC}"
    echo ""

    # Email
    echo -e "Введите email администратора (или нажмите Enter для значения по умолчанию):"
    read -p "Email [$ADMIN_EMAIL]: " INPUT_EMAIL
    ADMIN_EMAIL="${INPUT_EMAIL:-$ADMIN_EMAIL}"

    # Пароль
    echo ""
    echo -e "Введите пароль администратора (или нажмите Enter для значения по умолчанию):"
    echo -e "${YELLOW}⚠️  Внимание: пароль по умолчанию 'admin123' небезопасен!${NC}"
    read -p "Пароль [admin123]: " INPUT_PASSWORD
    ADMIN_PASSWORD="${INPUT_PASSWORD:-$ADMIN_PASSWORD}"

    while [[ ${#ADMIN_PASSWORD} -lt 6 ]]; do
        print_error "Пароль должен содержать минимум 6 символов!"
        read -p "Пароль: " ADMIN_PASSWORD
    done

    print_success "Данные администратора настроены"
    echo -e "   Email: ${GREEN}$ADMIN_EMAIL${NC}"
    echo -e "   Пароль: ${GREEN}$(echo $ADMIN_PASSWORD | sed 's/./*/g')${NC}"
}

# Обновление системы
update_system() {
    print_step
    echo -e "${CYAN}Обновление системы${NC}"
    
    if command -v apt-get &> /dev/null; then
        apt-get update -qq
        apt-get upgrade -y -qq
        print_success "Система обновлена (Debian/Ubuntu)"
    elif command -v yum &> /dev/null; then
        yum update -y -q
        print_success "Система обновлена (CentOS/RHEL)"
    fi
}

# Установка Node.js
install_nodejs() {
    print_step
    echo -e "${CYAN}Установка Node.js $NODE_VERSION${NC}"
    
    if command -v node &> /dev/null; then
        NODE_CURRENT=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
        if [[ $NODE_CURRENT -ge 16 ]]; then
            print_info "Node.js уже установлен: $(node -v)"
            return
        fi
    fi
    
    if command -v apt-get &> /dev/null; then
        curl -fsSL https://deb.nodesource.com/setup_$NODE_VERSION.x | bash -
        apt-get install -y nodejs
    elif command -v yum &> /dev/null; then
        curl -fsSL https://rpm.nodesource.com/setup_$NODE_VERSION.x | bash -
        yum install -y nodejs
    fi
    
    print_success "Node.js $(node -v) установлен"
}

# Установка PM2
install_pm2() {
    print_step
    echo -e "${CYAN}Установка PM2${NC}"
    
    if command -v pm2 &> /dev/null; then
        print_info "PM2 уже установлен"
    else
        npm install -g pm2
        print_success "PM2 установлен"
    fi
}

# Установка Nginx
install_nginx() {
    print_step
    echo -e "${CYAN}Установка Nginx${NC}"
    
    if command -v apt-get &> /dev/null; then
        apt-get install -y nginx
    elif command -v yum &> /dev/null; then
        yum install -y nginx
    fi
    
    systemctl enable nginx
    systemctl start nginx
    print_success "Nginx установлен и запущен"
}

# Создание директории
create_directories() {
    print_step
    echo -e "${CYAN}Создание директорий${NC}"
    
    mkdir -p "$WEB_ROOT"
    mkdir -p /var/log/salomtv
    
    print_success "Директории созданы"
}

# Копирование файлов
copy_files() {
    print_step
    echo -e "${CYAN}Копирование файлов${NC}"

    # Определяем источник - текущая директория или /workspace
    if [[ -d "/workspace/tv-streaming-full" ]]; then
        SOURCE_DIR="/workspace/tv-streaming-full"
    else
        SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
    fi

    echo -e "Источник: ${YELLOW}$SOURCE_DIR${NC}"

    # Проверяем наличие необходимых файлов
    if [[ ! -f "$SOURCE_DIR/package.json" ]]; then
        print_error "package.json не найден в $SOURCE_DIR"
        print_error "Убедитесь, что файлы проекта находятся в правильной директории"
        exit 1
    fi

    # Очищаем старую директорию если существует
    if [[ -d "$WEB_ROOT" ]]; then
        echo -e "${YELLOW}⚠️  Директория $WEB_ROOT уже существует${NC}"
        read -p "Очистить и переустановить? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            rm -rf "$WEB_ROOT"/*
            print_info "Директория очищена"
        else
            print_info "Используем существующую директорию"
        fi
    fi

    # Создаём директорию
    mkdir -p "$WEB_ROOT"

    # Копируем файлы
    cp -r "$SOURCE_DIR"/* "$WEB_ROOT/"

    # Права
    chown -R www-data:www-data "$WEB_ROOT"
    chmod -R 755 "$WEB_ROOT"

    print_success "Файлы скопированы в $WEB_ROOT"
}

# Установка зависимостей npm
install_npm_deps() {
    print_step
    echo -e "${CYAN}Установка зависимостей${NC}"
    
    cd "$WEB_ROOT"
    npm install --production
    
    print_success "Зависимости установлены"
}

# Инициализация базы данных
init_database() {
    print_step
    echo -e "${CYAN}Инициализация базы данных${NC}"

    cd "$WEB_ROOT"

    # Создаём файл с учётными данными администратора
    cat > "$WEB_ROOT/.admin_config" << EOF
ADMIN_EMAIL=$ADMIN_EMAIL
ADMIN_PASSWORD=$ADMIN_PASSWORD
EOF

    # Запускаем установку с пользовательскими данными
    npm run setup

    print_success "База данных инициализирована"
}

# Создание Nginx конфигурации
create_nginx_config() {
    print_step
    echo -e "${CYAN}Создание Nginx конфигурации${NC}"
    
    cat > /etc/nginx/sites-available/salomtv << EOF
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN;

    # Redirect to HTTPS
    return 301 https://\$server_name\$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name $DOMAIN;

    root $WEB_ROOT/public;
    index index.html;

    # SSL
    ssl_certificate /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;

    # Gzip
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml application/json application/javascript;

    # Static files caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # Main app
    location / {
        try_files \$uri \$uri/ /index.html;
    }

    # API proxy to Node.js
    location /api/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }

    # Logs
    access_log /var/log/nginx/salomtv_access.log;
    error_log /var/log/nginx/salomtv_error.log;
}
EOF

    # Активация
    rm -f /etc/nginx/sites-enabled/default
    ln -sf /etc/nginx/sites-available/salomtv /etc/nginx/sites-enabled/
    
    nginx -t
    systemctl reload nginx
    
    print_success "Nginx настроен"
}

# SSL сертификат
get_ssl() {
    print_step
    echo -e "${CYAN}Получение SSL сертификата${NC}"
    
    # Установка certbot
    if command -v apt-get &> /dev/null; then
        apt-get install -y certbot python3-certbot-nginx
    elif command -v yum &> /dev/null; then
        yum install -y certbot python3-certbot-nginx
    fi
    
    # Остановка nginx временно
    systemctl stop nginx
    
    # Получение сертификата
    certbot certonly --standalone -d "$DOMAIN" --non-interactive --agree-tos -m "admin@$DOMAIN" || true
    
    # Запуск nginx
    systemctl start nginx
    
    if [[ -d "/etc/letsencrypt/live/$DOMAIN" ]]; then
        print_success "SSL сертификат получен"
    else
        print_error "Не удалось получить SSL. Настройте позже вручную."
    fi
}

# Systemd сервис
create_service() {
    print_step
    echo -e "${CYAN}Создание systemd сервиса${NC}"
    
    cat > /etc/systemd/system/salomtv.service << EOF
[Unit]
Description=SalomTV Platform
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=$WEB_ROOT
ExecStart=/usr/bin/node $WEB_ROOT/server/index.js
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable salomtv
    systemctl start salomtv
    
    print_success "Сервис создан и запущен"
}

# Firewall
setup_firewall() {
    print_step
    echo -e "${CYAN}Настройка firewall${NC}"
    
    if command -v ufw &> /dev/null; then
        ufw --force enable
        ufw allow ssh
        ufw allow 'Nginx Full'
        print_success "UFW настроен"
    elif command -v firewall-cmd &> /dev/null; then
        firewall-cmd --permanent --add-service=http
        firewall-cmd --permanent --add-service=https
        firewall-cmd --permanent --add-service=ssh
        firewall-cmd --reload
        print_success "Firewalld настроен"
    fi
}

# Финальная информация
show_info() {
    print_step
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║${NC}              ${GREEN}УСТАНОВКА ЗАВЕРШЕНА УСПЕШНО!${NC}                      ${GREEN}║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${YELLOW}🌐 URL сайта:${NC}"
    echo -e "   https://$DOMAIN"
    echo ""
    echo -e "${YELLOW}👤 Админ-панель:${NC}"
    echo -e "   https://$DOMAIN/admin"
    echo ""
    echo -e "${YELLOW}📊 Статус сервиса:${NC}"
    echo -e "   sudo systemctl status salomtv"
    echo ""
    echo -e "${YELLOW}📝 Логи:${NC}"
    echo -e "   sudo journalctl -u salomtv -f"
    echo ""
    echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}👤 Данные администратора:${NC}"
    echo -e "   Email:    ${GREEN}$ADMIN_EMAIL${NC}"
    echo -e "   Пароль:   ${GREEN}$(echo $ADMIN_PASSWORD | sed 's/./*/g')${NC}"
    echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${GREEN}🎉 Спасибо за использование SalomTV!${NC}"
    echo ""
}

# Главная функция
main() {
    show_banner
    check_root
    get_domain
    get_admin_credentials
    update_system
    install_nodejs
    install_pm2
    install_nginx
    create_directories
    copy_files
    install_npm_deps
    init_database
    create_nginx_config
    get_ssl
    create_service
    setup_firewall
    show_info
}

main "$@"
