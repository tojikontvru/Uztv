/**
 * SalomTV — Authentication Middleware
 * JWT Verification & Authorization
 */

const jwt = require('jsonwebtoken');
const { db } = require('../database');

const JWT_SECRET = process.env.JWT_SECRET || 'salomtv-secret-key-change-in-production';
const JWT_EXPIRES = '7d';

// Генерация токена
function generateToken(user) {
  return jwt.sign(
    { 
      id: user.id, 
      username: user.username, 
      email: user.email,
      role: user.role 
    },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES }
  );
}

// Проверка токена
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    return null;
  }
}

// Middleware: Проверка авторизации
function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      error: 'Требуется авторизация'
    });
  }

  const token = authHeader.split(' ')[1];
  const decoded = verifyToken(token);

  if (!decoded) {
    return res.status(401).json({
      success: false,
      error: 'Недействительный или истёкший токен'
    });
  }

  // Получаем пользователя из БД
  const user = db.prepare('SELECT id, username, email, role FROM users WHERE id = ?').get(decoded.id);
  
  if (!user) {
    return res.status(401).json({
      success: false,
      error: 'Пользователь не найден'
    });
  }

  req.user = user;
  next();
}

// Middleware: Проверка прав администратора
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      error: 'Доступно только для администраторов'
    });
  }
  next();
}

// Middleware: Проверка на госте (не авторизован)
function guestOnly(req, res, next) {
  const authHeader = req.headers.authorization;
  
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    const decoded = verifyToken(token);
    
    if (decoded) {
      return res.status(400).json({
        success: false,
        error: 'Вы уже авторизованы'
      });
    }
  }
  
  next();
}

// Логирование активности
function logActivity(userId, action, entityType, entityId, details, ipAddress) {
  try {
    db.prepare(`
      INSERT INTO activity_logs (user_id, action, entity_type, entity_id, details, ip_address)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(userId, action, entityType, entityId, details, ipAddress);
  } catch (error) {
    console.error('Ошибка логирования:', error);
  }
}

module.exports = {
  JWT_SECRET,
  JWT_EXPIRES,
  generateToken,
  verifyToken,
  authenticate,
  requireAdmin,
  guestOnly,
  logActivity
};
