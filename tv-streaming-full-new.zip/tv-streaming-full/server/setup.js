/**
 * SalomTV — Database Setup Script
 * Инициализация базы данных
 */

const { setup } = require('./database');

console.log(`
╔══════════════════════════════════════════════════════╗
║                                                      ║
║   📺 SalomTV Platform — Database Setup              ║
║                                                      ║
╚══════════════════════════════════════════════════════╝
`);

try {
  setup();
  console.log('✅ Установка завершена успешно!');
  console.log('\nЗапустите сервер: npm start\n');
} catch (error) {
  console.error('❌ Ошибка установки:', error);
  process.exit(1);
}
