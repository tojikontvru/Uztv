/**
 * SalomTV Full Platform — Main Server
 * Node.js + Express + SQLite
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const path = require('path');

// Импорт маршрутов
const authRoutes = require('./routes/auth');
const channelsRoutes = require('./routes/channels');
const categoriesRoutes = require('./routes/categories');
const usersRoutes = require('./routes/users');
const publicRoutes = require('./routes/public');

// Инициализация приложения
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false
}));
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Статические файлы
app.use(express.static(path.join(__dirname, '../public')));

// API маршруты
app.use('/api/auth', authRoutes);
app.use('/api/channels', channelsRoutes);
app.use('/api/categories', categoriesRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/public', publicRoutes);

// Главная страница
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Страница входа
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/login.html'));
});

// Страница регистрации
app.get('/register', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/register.html'));
});

// Админ-панель
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/admin.html'));
});

// Обработка 404
app.use((req, res, next) => {
  if (req.accepts('html')) {
    res.status(404).sendFile(path.join(__dirname, '../public/404.html'));
  } else {
    res.status(404).json({ error: 'Not found' });
  }
});

// Глобальная обработка ошибок
app.use((err, req, res, next) => {
  console.error('Server Error:', err);
  res.status(err.status || 500).json({
    success: false,
    error: process.env.NODE_ENV === 'production' 
      ? 'Internal server error' 
      : err.message
  });
});

// Запуск сервера
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════════════╗
║                                                      ║
║   📺 SalomTV Platform запущен                        ║
║                                                      ║
║   🌐 URL: http://localhost:${PORT}                    ║
║   👤 Admin: http://localhost:${PORT}/admin            ║
║   📝 API:  http://localhost:${PORT}/api               ║
║                                                      ║
║   Первый запуск создаёт админа:                      ║
║   Email: admin@salomtv.uz                            ║
║   Password: admin123                                 ║
║                                                      ║
╚══════════════════════════════════════════════════════╝
  `);
});

module.exports = app;
