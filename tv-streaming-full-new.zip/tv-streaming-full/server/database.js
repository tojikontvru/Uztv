/**
 * SalomTV — Database Setup
 * SQLite Database Configuration
 */

const Database = require('better-sqlite3');
const path = require('path');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const DB_PATH = path.join(__dirname, '..', 'database.sqlite');
const db = new Database(DB_PATH);

// Включаем foreign keys
db.pragma('foreign_keys = ON');

// Инициализация таблиц
function initDatabase() {
  console.log('📦 Инициализация базы данных...');

  // Таблица пользователей
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT DEFAULT 'user' CHECK(role IN ('user', 'admin')),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Таблица категорий
  db.exec(`
    CREATE TABLE IF NOT EXISTS categories (
      id TEXT PRIMARY KEY,
      name_ru TEXT NOT NULL,
      name_en TEXT NOT NULL,
      name_uz TEXT NOT NULL,
      icon TEXT DEFAULT 'tv',
      sort_order INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Таблица каналов
  db.exec(`
    CREATE TABLE IF NOT EXISTS channels (
      id TEXT PRIMARY KEY,
      flusonic_id TEXT,
      title_ru TEXT NOT NULL,
      title_en TEXT,
      title_uz TEXT,
      description_ru TEXT,
      description_en TEXT,
      description_uz TEXT,
      image TEXT,
      url TEXT,
      background_image TEXT,
      payment_type TEXT DEFAULT 'free' CHECK(payment_type IN ('free', 'svod')),
      resolution TEXT DEFAULT 'HD' CHECK(resolution IN ('HD', 'FULL HD')),
      status INTEGER DEFAULT 1,
      has_access INTEGER DEFAULT 1,
      category_ids TEXT DEFAULT '[]',
      current_program TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Таблица сессий (для JWT refresh)
  db.exec(`
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      token TEXT NOT NULL,
      expires_at DATETIME NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )
  `);

  // Логи активности
  db.exec(`
    CREATE TABLE IF NOT EXISTS activity_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT,
      action TEXT NOT NULL,
      entity_type TEXT,
      entity_id TEXT,
      details TEXT,
      ip_address TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    )
  `);

  console.log('✅ Таблицы созданы');
}

// Создание администратора по умолчанию
function createDefaultAdmin() {
  const existingAdmin = db.prepare('SELECT id FROM users WHERE role = ?').get('admin');
  
  if (!existingAdmin) {
    const hashedPassword = bcrypt.hashSync('admin123', 10);
    const adminId = uuidv4();
    
    db.prepare(`
      INSERT INTO users (id, username, email, password, role)
      VALUES (?, ?, ?, ?, ?)
    `).run(adminId, 'admin', 'admin@salomtv.uz', hashedPassword, 'admin');
    
    console.log('👤 Создан администратор по умолчанию:');
    console.log('   Email: admin@salomtv.uz');
    console.log('   Password: admin123');
    console.log('   ⚠️  Измените пароль после первого входа!');
  }
}

// Инициализация категорий по умолчанию
function createDefaultCategories() {
  const count = db.prepare('SELECT COUNT(*) as count FROM categories').get().count;
  
  if (count === 0) {
    const defaultCategories = [
      { id: uuidv4(), name_ru: 'Основной пакет', name_en: 'Main Package', name_uz: 'Asosiy paket', icon: 'tv', order: 1 },
      { id: uuidv4(), name_ru: 'Местные каналы', name_en: 'Local Channels', name_uz: 'Mahalliy kanallar', icon: 'map-pin', order: 2 },
      { id: uuidv4(), name_ru: 'Кино', name_en: 'Movies', name_uz: 'Kino', icon: 'film', order: 3 },
      { id: uuidv4(), name_ru: 'Новости', name_en: 'News', name_uz: 'Yangiliklar', icon: 'rss', order: 4 },
      { id: uuidv4(), name_ru: 'Познавательные', name_en: 'Educational', name_uz: "O'qitish", icon: 'book', order: 5 },
      { id: uuidv4(), name_ru: 'Спорт', name_en: 'Sport', name_uz: 'Sport', icon: 'globe', order: 6 },
      { id: uuidv4(), name_ru: 'Детские', name_en: 'Kids', name_uz: 'Bolalar', icon: 'star', order: 7 },
      { id: uuidv4(), name_ru: 'Музыка', name_en: 'Music', name_uz: 'Musiqa', icon: 'music', order: 8 },
      { id: uuidv4(), name_ru: 'Международные', name_en: 'International', name_uz: 'Xalqaro', icon: 'globe', order: 9 }
    ];

    const insertCategory = db.prepare(`
      INSERT INTO categories (id, name_ru, name_en, name_uz, icon, sort_order)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

    defaultCategories.forEach(cat => {
      insertCategory.run(cat.id, cat.name_ru, cat.name_en, cat.name_uz, cat.icon, cat.order);
    });

    console.log('📂 Категории созданы');
  }
}

// Инициализация БД
function setup() {
  initDatabase();
  createDefaultAdmin();
  createDefaultCategories();
  console.log('✅ База данных готова к работе\n');
}

// Экспорт
module.exports = {
  db,
  setup,
  initDatabase,
  createDefaultAdmin,
  createDefaultCategories
};
