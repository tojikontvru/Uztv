/**
 * SalomTV — Public Routes
 * Public API endpoints (no auth required)
 */

const express = require('express');
const { db } = require('../database');

const router = express.Router();

// ============================================
// GET /api/public/channels — Публичный список каналов
// ============================================
router.get('/channels', (req, res) => {
  try {
    const { category, search } = req.query;

    let query = 'SELECT * FROM channels WHERE status = 1';
    const params = [];

    // Фильтр по категории
    if (category) {
      query += ` AND category_ids LIKE ?`;
      params.push(`%"${category}"%`);
    }

    // Поиск
    if (search) {
      query += ` AND (title_ru LIKE ? OR title_en LIKE ? OR title_uz LIKE ?)`;
      const searchPattern = `%${search}%`;
      params.push(searchPattern, searchPattern, searchPattern);
    }

    query += ' ORDER BY title_ru ASC';

    const channels = db.prepare(query).all(...params);

    const result = channels.map(ch => ({
      ...ch,
      category_ids: JSON.parse(ch.category_ids || '[]')
    }));

    res.json({
      tv_channels: result,
      count: result.length
    });

  } catch (error) {
    console.error('Public channels error:', error);
    res.status(500).json({
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// GET /api/public/categories — Публичный список категорий
// ============================================
router.get('/categories', (req, res) => {
  try {
    const categories = db.prepare('SELECT * FROM categories ORDER BY sort_order ASC, name_ru ASC').all();
    
    res.json({
      categories,
      count: categories.length
    });

  } catch (error) {
    console.error('Public categories error:', error);
    res.status(500).json({
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// GET /api/public/stats — Публичная статистика
// ============================================
router.get('/stats', (req, res) => {
  try {
    const totalChannels = db.prepare('SELECT COUNT(*) as count FROM channels WHERE status = 1').get().count;
    const totalCategories = db.prepare('SELECT COUNT(*) as count FROM categories').get().count;

    res.json({
      total_channels: totalChannels,
      total_categories: totalCategories,
      version: '1.0.0'
    });

  } catch (error) {
    console.error('Public stats error:', error);
    res.status(500).json({
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// GET /api/public/health — Проверка здоровья API
// ============================================
router.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

module.exports = router;
