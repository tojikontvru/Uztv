/**
 * SalomTV — Channels Routes
 * CRUD Operations for TV Channels
 */

const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { db } = require('../database');
const { authenticate, requireAdmin, logActivity } = require('../middleware/auth');

const router = express.Router();

// ============================================
// GET /api/channels — Список каналов
// ============================================
router.get('/', (req, res) => {
  try {
    const { category, search, status, payment } = req.query;

    let query = 'SELECT * FROM channels WHERE 1=1';
    const params = [];

    // Фильтр по категории
    if (category) {
      query += ` AND category_ids LIKE ?`;
      params.push(`%"${category}"%`);
    }

    // Поиск
    if (search) {
      query += ` AND (title_ru LIKE ? OR title_en LIKE ? OR title_uz LIKE ?)`;
      const searchPattern = `%${search}%`;
      params.push(searchPattern, searchPattern, searchPattern);
    }

    // Фильтр по статусу
    if (status !== undefined) {
      query += ` AND status = ?`;
      params.push(parseInt(status));
    }

    // Фильтр по типу оплаты
    if (payment) {
      query += ` AND payment_type = ?`;
      params.push(payment);
    }

    query += ' ORDER BY title_ru ASC';

    const channels = db.prepare(query).all(...params);

    // Парсинг category_ids
    const result = channels.map(ch => ({
      ...ch,
      category_ids: JSON.parse(ch.category_ids || '[]')
    }));

    res.json({
      success: true,
      count: result.length,
      channels: result
    });

  } catch (error) {
    console.error('Get channels error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// GET /api/channels/:id — Один канал
// ============================================
router.get('/:id', (req, res) => {
  try {
    const { id } = req.params;

    const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(id);

    if (!channel) {
      return res.status(404).json({
        success: false,
        error: 'Канал не найден'
      });
    }

    channel.category_ids = JSON.parse(channel.category_ids || '[]');

    res.json({
      success: true,
      channel
    });

  } catch (error) {
    console.error('Get channel error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// POST /api/channels — Создание канала (Admin)
// ============================================
router.post('/', authenticate, requireAdmin, (req, res) => {
  try {
    const {
      flusonic_id,
      title_ru, title_en, title_uz,
      description_ru, description_en, description_uz,
      image, url, background_image,
      payment_type, resolution,
      category_ids
    } = req.body;

    // Валидация
    if (!title_ru) {
      return res.status(400).json({
        success: false,
        error: 'Название канала обязательно'
      });
    }

    const channelId = uuidv4();

    db.prepare(`
      INSERT INTO channels (
        id, flusonic_id,
        title_ru, title_en, title_uz,
        description_ru, description_en, description_uz,
        image, url, background_image,
        payment_type, resolution,
        category_ids
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      channelId,
      flusonic_id || null,
      title_ru, title_en || title_ru, title_uz || title_ru,
      description_ru || '', description_en || '', description_uz || '',
      image || '', url || '', background_image || '',
      payment_type || 'free', resolution || 'HD',
      JSON.stringify(category_ids || [])
    );

    logActivity(req.user.id, 'create', 'channel', channelId, `Created channel: ${title_ru}`, req.ip);

    const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(channelId);
    channel.category_ids = JSON.parse(channel.category_ids || '[]');

    res.status(201).json({
      success: true,
      message: 'Канал создан',
      channel
    });

  } catch (error) {
    console.error('Create channel error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// PUT /api/channels/:id — Обновление канала (Admin)
// ============================================
router.put('/:id', authenticate, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;
    const {
      flusonic_id,
      title_ru, title_en, title_uz,
      description_ru, description_en, description_uz,
      image, url, background_image,
      payment_type, resolution,
      status, has_access,
      category_ids,
      current_program
    } = req.body;

    // Проверка существования
    const existing = db.prepare('SELECT id FROM channels WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({
        success: false,
        error: 'Канал не найден'
      });
    }

    // Формирование запроса обновления
    const updates = [];
    const values = [];

    const fields = {
      flusonic_id, image, url, background_image,
      description_ru, description_en, description_uz,
      payment_type, resolution,
      current_program
    };

    Object.entries(fields).forEach(([key, value]) => {
      if (value !== undefined) {
        updates.push(`${key} = ?`);
        values.push(value);
      }
    });

    // Многоязычные названия
    if (title_ru) {
      updates.push('title_ru = ?');
      values.push(title_ru);
    }
    if (title_en) {
      updates.push('title_en = ?');
      values.push(title_en);
    }
    if (title_uz) {
      updates.push('title_uz = ?');
      values.push(title_uz);
    }

    // Булевы поля
    if (status !== undefined) {
      updates.push('status = ?');
      values.push(status ? 1 : 0);
    }
    if (has_access !== undefined) {
      updates.push('has_access = ?');
      values.push(has_access ? 1 : 0);
    }

    // JSON поле
    if (category_ids !== undefined) {
      updates.push('category_ids = ?');
      values.push(JSON.stringify(category_ids));
    }

    updates.push('updated_at = CURRENT_TIMESTAMP');
    values.push(id);

    db.prepare(`UPDATE channels SET ${updates.join(', ')} WHERE id = ?`).run(...values);

    logActivity(req.user.id, 'update', 'channel', id, `Updated channel: ${title_ru || id}`, req.ip);

    const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(id);
    channel.category_ids = JSON.parse(channel.category_ids || '[]');

    res.json({
      success: true,
      message: 'Канал обновлён',
      channel
    });

  } catch (error) {
    console.error('Update channel error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// DELETE /api/channels/:id — Удаление канала (Admin)
// ============================================
router.delete('/:id', authenticate, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;

    const existing = db.prepare('SELECT title_ru FROM channels WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({
        success: false,
        error: 'Канал не найден'
      });
    }

    db.prepare('DELETE FROM channels WHERE id = ?').run(id);

    logActivity(req.user.id, 'delete', 'channel', id, `Deleted channel: ${existing.title_ru}`, req.ip);

    res.json({
      success: true,
      message: 'Канал удалён'
    });

  } catch (error) {
    console.error('Delete channel error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// PATCH /api/channels/:id/status — Включение/выключение (Admin)
// ============================================
router.patch('/:id/status', authenticate, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const existing = db.prepare('SELECT id FROM channels WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({
        success: false,
        error: 'Канал не найден'
      });
    }

    db.prepare('UPDATE channels SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(status ? 1 : 0, id);

    logActivity(req.user.id, 'toggle_status', 'channel', id, `Channel status: ${status ? 'enabled' : 'disabled'}`, req.ip);

    res.json({
      success: true,
      message: status ? 'Канал включён' : 'Канал отключён'
    });

  } catch (error) {
    console.error('Toggle channel status error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

module.exports = router;
