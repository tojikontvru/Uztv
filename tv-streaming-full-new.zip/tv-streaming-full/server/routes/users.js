/**
 * SalomTV — Users Routes
 * Admin User Management
 */

const express = require('express');
const bcrypt = require('bcryptjs');
const { db } = require('../database');
const { authenticate, requireAdmin, logActivity } = require('../middleware/auth');

const router = express.Router();

// ============================================
// GET /api/users — Список пользователей (Admin)
// ============================================
router.get('/', authenticate, requireAdmin, (req, res) => {
  try {
    const { page = 1, limit = 20, search, role } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let query = 'SELECT id, username, email, role, created_at, updated_at FROM users WHERE 1=1';
    let countQuery = 'SELECT COUNT(*) as total FROM users WHERE 1=1';
    const params = [];
    const countParams = [];

    // Фильтр по роли
    if (role) {
      query += ' AND role = ?';
      countQuery += ' AND role = ?';
      params.push(role);
      countParams.push(role);
    }

    // Поиск
    if (search) {
      query += ' AND (username LIKE ? OR email LIKE ?)';
      countQuery += ' AND (username LIKE ? OR email LIKE ?)';
      const searchPattern = `%${search}%`;
      params.push(searchPattern, searchPattern);
      countParams.push(searchPattern, searchPattern);
    }

    // Пагинация
    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), offset);

    const users = db.prepare(query).all(...params);
    const total = db.prepare(countQuery).get(...countParams).total;

    res.json({
      success: true,
      users,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });

  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// GET /api/users/:id — Один пользователь (Admin)
// ============================================
router.get('/:id', authenticate, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;

    const user = db.prepare('SELECT id, username, email, role, created_at, updated_at FROM users WHERE id = ?').get(id);

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'Пользователь не найден'
      });
    }

    // Получаем активность пользователя
    const activity = db.prepare('SELECT * FROM activity_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 10').all(id);

    res.json({
      success: true,
      user,
      activity
    });

  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// PUT /api/users/:id/role — Изменение роли (Admin)
// ============================================
router.put('/:id/role', authenticate, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;
    const { role } = req.body;

    // Нельзя изменить свою роль
    if (id === req.user.id) {
      return res.status(400).json({
        success: false,
        error: 'Нельзя изменить свою роль'
      });
    }

    // Валидация роли
    if (!['user', 'admin'].includes(role)) {
      return res.status(400).json({
        success: false,
        error: 'Некорректная роль'
      });
    }

    const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({
        success: false,
        error: 'Пользователь не найден'
      });
    }

    db.prepare('UPDATE users SET role = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(role, id);

    logActivity(req.user.id, 'change_role', 'user', id, `Changed role to ${role}`, req.ip);

    const user = db.prepare('SELECT id, username, email, role, created_at, updated_at FROM users WHERE id = ?').get(id);

    res.json({
      success: true,
      message: `Роль изменена на ${role === 'admin' ? 'администратор' : 'пользователь'}`,
      user
    });

  } catch (error) {
    console.error('Change role error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// PUT /api/users/:id/password — Сброс пароля (Admin)
// ============================================
router.put('/:id/password', authenticate, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;
    const { newPassword } = req.body;

    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({
        success: false,
        error: 'Пароль минимум 6 символов'
      });
    }

    const existing = db.prepare('SELECT username FROM users WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({
        success: false,
        error: 'Пользователь не найден'
      });
    }

    const hashedPassword = bcrypt.hashSync(newPassword, 10);
    db.prepare('UPDATE users SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(hashedPassword, id);

    logActivity(req.user.id, 'reset_password', 'user', id, `Password reset by admin`, req.ip);

    res.json({
      success: true,
      message: 'Пароль сброшен'
    });

  } catch (error) {
    console.error('Reset password error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// DELETE /api/users/:id — Удаление пользователя (Admin)
// ============================================
router.delete('/:id', authenticate, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;

    // Нельзя удалить себя
    if (id === req.user.id) {
      return res.status(400).json({
        success: false,
        error: 'Нельзя удалить себя'
      });
    }

    const existing = db.prepare('SELECT username, role FROM users WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({
        success: false,
        error: 'Пользователь не найден'
      });
    }

    // Нельзя удалить последнего админа
    if (existing.role === 'admin') {
      const adminCount = db.prepare('SELECT COUNT(*) as count FROM users WHERE role = ?').get('admin').count;
      if (adminCount <= 1) {
        return res.status(400).json({
          success: false,
          error: 'Нельзя удалить последнего администратора'
        });
      }
    }

    db.prepare('DELETE FROM users WHERE id = ?').run(id);

    logActivity(req.user.id, 'delete', 'user', id, `Deleted user: ${existing.username}`, req.ip);

    res.json({
      success: true,
      message: 'Пользователь удалён'
    });

  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// GET /api/users/stats — Статистика (Admin)
// ============================================
router.get('/stats/overview', authenticate, requireAdmin, (req, res) => {
  try {
    const totalUsers = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
    const totalAdmins = db.prepare('SELECT COUNT(*) as count FROM users WHERE role = ?').get('admin').count;
    const totalChannels = db.prepare('SELECT COUNT(*) as count FROM channels').get().count;
    const activeChannels = db.prepare('SELECT COUNT(*) as count FROM channels WHERE status = 1').get().count;
    const totalCategories = db.prepare('SELECT COUNT(*) as count FROM categories').get().count;

    // Новые пользователи за неделю
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
    const newUsersWeek = db.prepare('SELECT COUNT(*) as count FROM users WHERE created_at > ?').get(weekAgo).count;

    // Последняя активность
    const recentActivity = db.prepare(`
      SELECT al.*, u.username 
      FROM activity_logs al 
      LEFT JOIN users u ON al.user_id = u.id 
      ORDER BY al.created_at DESC 
      LIMIT 10
    `).all();

    res.json({
      success: true,
      stats: {
        users: {
          total: totalUsers,
          admins: totalAdmins,
          newThisWeek: newUsersWeek
        },
        channels: {
          total: totalChannels,
          active: activeChannels,
          inactive: totalChannels - activeChannels
        },
        categories: {
          total: totalCategories
        },
        recentActivity
      }
    });

  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

module.exports = router;
