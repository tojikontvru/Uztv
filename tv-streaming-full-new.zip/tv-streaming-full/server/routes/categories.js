/**
 * SalomTV — Categories Routes
 * CRUD Operations for Categories
 */

const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { db } = require('../database');
const { authenticate, requireAdmin, logActivity } = require('../middleware/auth');

const router = express.Router();

// ============================================
// GET /api/categories — Список категорий
// ============================================
router.get('/', (req, res) => {
  try {
    const categories = db.prepare('SELECT * FROM categories ORDER BY sort_order ASC, name_ru ASC').all();

    // Добавляем количество каналов в каждой категории
    const result = categories.map(cat => {
      const channels = db.prepare('SELECT category_ids FROM channels WHERE status = 1').all();
      let count = 0;
      
      channels.forEach(ch => {
        try {
          const ids = JSON.parse(ch.category_ids || '[]');
          if (ids.includes(cat.id)) count++;
        } catch (e) {}
      });

      return {
        ...cat,
        channel_count: count
      };
    });

    res.json({
      success: true,
      count: result.length,
      categories: result
    });

  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// GET /api/categories/:id — Одна категория
// ============================================
router.get('/:id', (req, res) => {
  try {
    const { id } = req.params;

    const category = db.prepare('SELECT * FROM categories WHERE id = ?').get(id);

    if (!category) {
      return res.status(404).json({
        success: false,
        error: 'Категория не найдена'
      });
    }

    res.json({
      success: true,
      category
    });

  } catch (error) {
    console.error('Get category error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// POST /api/categories — Создание категории (Admin)
// ============================================
router.post('/', authenticate, requireAdmin, (req, res) => {
  try {
    const { name_ru, name_en, name_uz, icon, sort_order } = req.body;

    // Валидация
    if (!name_ru) {
      return res.status(400).json({
        success: false,
        error: 'Название категории обязательно'
      });
    }

    // Получаем максимальный sort_order
    const maxOrder = db.prepare('SELECT MAX(sort_order) as max FROM categories').get().max || 0;

    const categoryId = uuidv4();

    db.prepare(`
      INSERT INTO categories (id, name_ru, name_en, name_uz, icon, sort_order)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      categoryId,
      name_ru,
      name_en || name_ru,
      name_uz || name_ru,
      icon || 'folder',
      sort_order !== undefined ? sort_order : maxOrder + 1
    );

    logActivity(req.user.id, 'create', 'category', categoryId, `Created category: ${name_ru}`, req.ip);

    const category = db.prepare('SELECT * FROM categories WHERE id = ?').get(categoryId);

    res.status(201).json({
      success: true,
      message: 'Категория создана',
      category
    });

  } catch (error) {
    console.error('Create category error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// PUT /api/categories/:id — Обновление категории (Admin)
// ============================================
router.put('/:id', authenticate, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;
    const { name_ru, name_en, name_uz, icon, sort_order } = req.body;

    // Проверка существования
    const existing = db.prepare('SELECT * FROM categories WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({
        success: false,
        error: 'Категория не найдена'
      });
    }

    const updates = [];
    const values = [];

    if (name_ru) {
      updates.push('name_ru = ?');
      values.push(name_ru);
    }
    if (name_en) {
      updates.push('name_en = ?');
      values.push(name_en);
    }
    if (name_uz) {
      updates.push('name_uz = ?');
      values.push(name_uz);
    }
    if (icon) {
      updates.push('icon = ?');
      values.push(icon);
    }
    if (sort_order !== undefined) {
      updates.push('sort_order = ?');
      values.push(sort_order);
    }

    if (updates.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Не указаны данные для обновления'
      });
    }

    values.push(id);

    db.prepare(`UPDATE categories SET ${updates.join(', ')} WHERE id = ?`).run(...values);

    logActivity(req.user.id, 'update', 'category', id, `Updated category: ${name_ru || existing.name_ru}`, req.ip);

    const category = db.prepare('SELECT * FROM categories WHERE id = ?').get(id);

    res.json({
      success: true,
      message: 'Категория обновлена',
      category
    });

  } catch (error) {
    console.error('Update category error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// DELETE /api/categories/:id — Удаление категории (Admin)
// ============================================
router.delete('/:id', authenticate, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;

    const existing = db.prepare('SELECT name_ru FROM categories WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({
        success: false,
        error: 'Категория не найдена'
      });
    }

    // Удаляем категорию из всех каналов
    const channels = db.prepare('SELECT id, category_ids FROM channels').all();
    
    channels.forEach(ch => {
      try {
        const ids = JSON.parse(ch.category_ids || '[]');
        const newIds = ids.filter(catId => catId !== id);
        if (newIds.length !== ids.length) {
          db.prepare('UPDATE channels SET category_ids = ? WHERE id = ?')
            .run(JSON.stringify(newIds), ch.id);
        }
      } catch (e) {}
    });

    db.prepare('DELETE FROM categories WHERE id = ?').run(id);

    logActivity(req.user.id, 'delete', 'category', id, `Deleted category: ${existing.name_ru}`, req.ip);

    res.json({
      success: true,
      message: 'Категория удалена'
    });

  } catch (error) {
    console.error('Delete category error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// PUT /api/categories/reorder — Изменение порядка (Admin)
// ============================================
router.put('/reorder', authenticate, requireAdmin, (req, res) => {
  try {
    const { order } = req.body; // Массив { id, sort_order }

    if (!Array.isArray(order)) {
      return res.status(400).json({
        success: false,
        error: 'Неверный формат данных'
      });
    }

    const updateStmt = db.prepare('UPDATE categories SET sort_order = ? WHERE id = ?');

    order.forEach(item => {
      updateStmt.run(item.sort_order, item.id);
    });

    logActivity(req.user.id, 'reorder', 'category', null, 'Categories reordered', req.ip);

    res.json({
      success: true,
      message: 'Порядок категорий обновлён'
    });

  } catch (error) {
    console.error('Reorder categories error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

module.exports = router;
