/**
 * SalomTV — Authentication Routes
 * Registration, Login, Profile
 */

const express = require('express');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { db } = require('../database');
const { generateToken, authenticate, guestOnly, logActivity } = require('../middleware/auth');

const router = express.Router();

// ============================================
// POST /api/auth/register — Регистрация
// ============================================
router.post('/register', guestOnly, (req, res) => {
  try {
    const { username, email, password } = req.body;

    // Валидация
    if (!username || !email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Все поля обязательны'
      });
    }

    if (username.length < 3 || username.length > 30) {
      return res.status(400).json({
        success: false,
        error: 'Имя пользователя: 3-30 символов'
      });
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({
        success: false,
        error: 'Некорректный email'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        error: 'Пароль минимум 6 символов'
      });
    }

    // Проверка существования
    const existingUser = db.prepare('SELECT id FROM users WHERE email = ? OR username = ?')
      .get(email.toLowerCase(), username.toLowerCase());

    if (existingUser) {
      return res.status(400).json({
        success: false,
        error: 'Пользователь с таким email или именем уже существует'
      });
    }

    // Создание пользователя
    const hashedPassword = bcrypt.hashSync(password, 10);
    const userId = uuidv4();

    db.prepare(`
      INSERT INTO users (id, username, email, password, role)
      VALUES (?, ?, ?, ?, ?)
    `).run(userId, username.toLowerCase(), email.toLowerCase(), hashedPassword, 'user');

    const user = db.prepare('SELECT id, username, email, role FROM users WHERE id = ?').get(userId);
    const token = generateToken(user);

    logActivity(userId, 'register', 'user', userId, 'New user registration', req.ip);

    res.status(201).json({
      success: true,
      message: 'Регистрация успешна',
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role
      }
    });

  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// POST /api/auth/login — Вход
// ============================================
router.post('/login', guestOnly, (req, res) => {
  try {
    const { email, password } = req.body;

    // Валидация
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Email и пароль обязательны'
      });
    }

    // Поиск пользователя
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase());

    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'Неверный email или пароль'
      });
    }

    // Проверка пароля
    if (!bcrypt.compareSync(password, user.password)) {
      return res.status(401).json({
        success: false,
        error: 'Неверный email или пароль'
      });
    }

    // Генерация токена
    const token = generateToken(user);

    logActivity(user.id, 'login', 'user', user.id, 'User logged in', req.ip);

    res.json({
      success: true,
      message: 'Вход выполнен',
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// GET /api/auth/me — Текущий пользователь
// ============================================
router.get('/me', authenticate, (req, res) => {
  res.json({
    success: true,
    user: req.user
  });
});

// ============================================
// PUT /api/auth/password — Смена пароля
// ============================================
router.put('/password', authenticate, (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const userId = req.user.id;

    // Получаем текущий пароль
    const user = db.prepare('SELECT password FROM users WHERE id = ?').get(userId);

    if (!bcrypt.compareSync(currentPassword, user.password)) {
      return res.status(400).json({
        success: false,
        error: 'Неверный текущий пароль'
      });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({
        success: false,
        error: 'Новый пароль минимум 6 символов'
      });
    }

    // Обновляем пароль
    const hashedPassword = bcrypt.hashSync(newPassword, 10);
    db.prepare('UPDATE users SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(hashedPassword, userId);

    logActivity(userId, 'password_change', 'user', userId, 'Password changed', req.ip);

    res.json({
      success: true,
      message: 'Пароль успешно изменён'
    });

  } catch (error) {
    console.error('Password change error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

// ============================================
// PUT /api/auth/profile — Обновление профиля
// ============================================
router.put('/profile', authenticate, (req, res) => {
  try {
    const { username, email } = req.body;
    const userId = req.user.id;

    // Проверка уникальности
    if (username || email) {
      const existing = db.prepare(`
        SELECT id FROM users 
        WHERE (username = ? OR email = ?) AND id != ?
      `).get(
        username?.toLowerCase() || '', 
        email?.toLowerCase() || '', 
        userId
      );

      if (existing) {
        return res.status(400).json({
          success: false,
          error: 'Имя пользователя или email уже заняты'
        });
      }
    }

    // Обновление
    const updates = [];
    const values = [];

    if (username) {
      updates.push('username = ?');
      values.push(username.toLowerCase());
    }
    if (email) {
      updates.push('email = ?');
      values.push(email.toLowerCase());
    }

    if (updates.length > 0) {
      updates.push('updated_at = CURRENT_TIMESTAMP');
      values.push(userId);
      
      db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...values);
    }

    const updatedUser = db.prepare('SELECT id, username, email, role FROM users WHERE id = ?').get(userId);

    logActivity(userId, 'profile_update', 'user', userId, 'Profile updated', req.ip);

    res.json({
      success: true,
      message: 'Профиль обновлён',
      user: updatedUser
    });

  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500).json({
      success: false,
      error: 'Ошибка сервера'
    });
  }
});

module.exports = router;
